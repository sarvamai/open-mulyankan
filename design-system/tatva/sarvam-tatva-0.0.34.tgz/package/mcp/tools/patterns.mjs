/**
 * get_patterns tool
 *
 * Returns full copy-paste composition blocks for common UI tasks.
 * These are real-world, production-ready patterns combining multiple Tatva
 * components — not isolated prop demos. Agents should use these as starting
 * templates and adapt to their specific needs.
 */

import * as v from "valibot";

// ─── Pattern Registry ────────────────────────────────────────────────────────

const PATTERNS = {
  "form-with-validation": {
    title: "Form with Validation (react-hook-form + zod)",
    description: "Standard form pattern with validation, error messages, and submit handling.",
    components: ["Input", "Select", "Switch", "Checkbox", "Button", "Box", "Text"],
    code: `"use client";

import { useForm, Controller } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { Box, Input, Select, Switch, Button, Text } from "@sarvam/tatva";

const schema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters"),
  email: z.string().email("Invalid email address"),
  role: z.string().min(1, "Please select a role"),
  notifications: z.boolean(),
});

type FormValues = z.infer<typeof schema>;

export function CreateUserForm({ onSubmit }: { onSubmit: (data: FormValues) => void }) {
  const { control, handleSubmit, formState: { errors, isSubmitting } } = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: { name: "", email: "", role: "", notifications: true },
  });

  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <Box display="flex" direction="column" gap={10}>
        <Controller
          name="name"
          control={control}
          render={({ field }) => (
            <Input
              {...field}
              label="Full Name"
              placeholder="John Doe"
              error={errors.name?.message}
            />
          )}
        />
        <Controller
          name="email"
          control={control}
          render={({ field }) => (
            <Input
              {...field}
              label="Email"
              placeholder="john@example.com"
              type="email"
              error={errors.email?.message}
            />
          )}
        />
        <Controller
          name="role"
          control={control}
          render={({ field }) => (
            <Select
              {...field}
              label="Role"
              placeholder="Select a role"
              options={[
                { label: "Admin", value: "admin" },
                { label: "Editor", value: "editor" },
                { label: "Viewer", value: "viewer" },
              ]}
              error={errors.role?.message}
            />
          )}
        />
        <Controller
          name="notifications"
          control={control}
          render={({ field }) => (
            <Switch
              checked={field.value}
              onCheckedChange={field.onChange}
              label="Email notifications"
            />
          )}
        />
        <Button type="submit" width="full" isLoading={isSubmitting}>
          Create User
        </Button>
      </Box>
    </form>
  );
}`,
  },

  "data-table-with-filters": {
    title: "Data Table with Search, Filters & Pagination",
    description:
      "Production table pattern with search, sorting, pagination, and empty state. " +
      "Page Header stays mounted; Table stays mounted too — update data/isLoading/isRefetching in place " +
      "(do not remount via unstable key or conditional unmount; stagger replays under AnimationProvider). " +
      "Set column width with TableColumn.size only (not style.width on cell content). " +
      "Text columns truncate with tooltip-on-overflow by default (TableColumn.truncate). " +
      "Prefer Table empty props when the table itself is empty.",
    components: ["Table", "Input", "Box", "EmptyState", "Header", "Badge"],
    code: `"use client";

import { useState, useMemo } from "react";
import { Box, Table, Input, EmptyState, Header, Badge } from "@sarvam/tatva";
import type { TableColumn } from "@sarvam/tatva";

interface User {
  id: string;
  name: string;
  email: string;
  role: string;
  status: "active" | "inactive";
  createdAt: string;
}

const columns: TableColumn<User>[] = [
  { id: "name", header: "Name", accessorKey: "name", enableSorting: true, size: 200 },
  { id: "email", header: "Email", accessorKey: "email", enableSorting: true, size: 240 },
  { id: "role", header: "Role", accessorKey: "role", enableSorting: true, size: 120 },
  {
    id: "status",
    header: "Status",
    accessorKey: "status",
    size: 120,
    cell: ({ row }) => (
      <Badge variant={row.original.status === "active" ? "green" : "default"} size="sm">
        {row.original.status}
      </Badge>
    ),
  },
  { id: "createdAt", header: "Joined", accessorKey: "createdAt", enableSorting: true, size: 140 },
];

export function UsersTable({ users }: { users: User[] }) {
  const [search, setSearch] = useState("");

  const filtered = useMemo(
    () => users.filter((u) =>
      u.name.toLowerCase().includes(search.toLowerCase()) ||
      u.email.toLowerCase().includes(search.toLowerCase())
    ),
    [users, search]
  );

  return (
    <Box display="flex" direction="column" gap={12}>
      <Header
        type="main"
        left={{ title: "Users" }}
        actions={[{ label: "Add User", icon: "plus", onClick: () => {} }]}
      />
      <Box display="flex" direction="column" gap={10}>
        <Input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search by name or email..."
          icon="search"
        />
        {filtered.length === 0 ? (
          <EmptyState
            heading="No users found"
            body="Try adjusting your search or add a new user."
            imageSrc="/images/empty-table.png"
            actions={[
              { children: "Clear search", variant: "outline", onClick: () => setSearch("") },
              { children: "Add User", variant: "primary", onClick: () => {} },
            ]}
          />
        ) : (
          <Table
            data={filtered}
            columns={columns}
            pageSize={10}
            getRowId={(row) => row.id}
          />
        )}
      </Box>
    </Box>
  );
}`,
  },

  "dashboard-analytics": {
    title: "Analytics Dashboard with Metric Cards & Charts",
    description: "Dashboard grid with KPI metric cards wrapping charts, following the MetricCard-always-wraps-charts rule.",
    components: ["MetricCard", "BarChart", "LineChart", "Sparkline", "Box", "Header"],
    code: `"use client";

import { Box, Header, MetricCard, BarChart, LineChart, Sparkline } from "@sarvam/tatva";

const revenueData = [
  { label: "Jan", value: 4200 },
  { label: "Feb", value: 5100 },
  { label: "Mar", value: 4800 },
  { label: "Apr", value: 6300 },
  { label: "May", value: 7100 },
  { label: "Jun", value: 6800 },
];

const usersData = [
  { label: "Mon", value: 120 },
  { label: "Tue", value: 145 },
  { label: "Wed", value: 132 },
  { label: "Thu", value: 167 },
  { label: "Fri", value: 189 },
];

export function AnalyticsDashboard() {
  return (
    <Box display="flex" direction="column" gap={12}>
      <Header type="main" left={{ title: "Analytics" }} />

      <Box display="flex" wrap="wrap" gap={12}>
        <MetricCard
          title="Total Revenue"
          value="$34,200"
          change={{ value: 12.5, direction: "up" }}
        >
          <BarChart
            data={revenueData}
            series={[{ key: "value", label: "Revenue" }]}
            height={120}
          />
        </MetricCard>

        <MetricCard
          title="Active Users"
          value="1,247"
          change={{ value: 8.2, direction: "up" }}
        >
          <LineChart
            data={usersData}
            series={[{ key: "value", label: "Users" }]}
            height={120}
          />
        </MetricCard>

        <MetricCard
          title="Conversion Rate"
          value="3.2%"
          change={{ value: -0.4, direction: "down" }}
        >
          <Sparkline data={[3.1, 3.4, 3.2, 3.0, 3.3, 3.2]} height={40} />
        </MetricCard>
      </Box>
    </Box>
  );
}`,
  },

  "dialog-confirmation": {
    title: "Confirmation Dialog with Actions",
    description: "Dialog for destructive or important actions with cancel/confirm buttons.",
    components: ["Dialog", "Button", "Text", "Box"],
    code: `"use client";

import { useState } from "react";
import { Dialog, Button } from "@sarvam/tatva";

export function DeleteConfirmation({
  itemName,
  onDelete,
}: {
  itemName: string;
  onDelete: () => Promise<void>;
}) {
  const [open, setOpen] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);

  const handleDelete = async () => {
    setIsDeleting(true);
    try {
      await onDelete();
      setOpen(false);
    } finally {
      setIsDeleting(false);
    }
  };

  return (
    <>
      <Button variant="destructive" icon="trash" onClick={() => setOpen(true)}>
        Delete
      </Button>
      <Dialog
        open={open}
        onOpenChange={setOpen}
        title={\`Delete \${itemName}?\`}
        description="This action cannot be undone. All associated data will be permanently removed."
        actions={[
          { label: "Cancel", variant: "outline", onClick: () => setOpen(false) },
          {
            label: "Delete",
            variant: "destructive",
            onClick: handleDelete,
            isLoading: isDeleting,
          },
        ]}
      />
    </>
  );
}`,
  },

  "settings-page": {
    title: "Settings Page with Sections & Options",
    description:
      "Settings layout with OptionGroup sections. Separate regions with gap={12} — do not add Divider by default. " +
      "Apps with a PageShell wrapper should pass the title/actions there instead of composing Header inline.",
    components: ["OptionItem", "OptionGroup", "Switch", "Select", "Box", "Header", "Button"],
    code: `"use client";

import { useState } from "react";
import { Box, Header, OptionGroup, OptionItem, Switch, Select, Button } from "@sarvam/tatva";

export function SettingsPage() {
  const [darkMode, setDarkMode] = useState(false);
  const [emailNotifs, setEmailNotifs] = useState(true);
  const [language, setLanguage] = useState("en");

  return (
    <Box display="flex" direction="column" gap={12}>
      <Header type="main" left={{ title: "Settings" }} />

      <OptionGroup title="Appearance">
        <OptionItem
          title="Dark mode"
          description="Use dark theme across the application"
          trailing={<Switch checked={darkMode} onCheckedChange={setDarkMode} />}
        />
        <OptionItem
          title="Language"
          description="Select your preferred language"
          trailing={
            <Select
              value={language}
              onChange={(val) => setLanguage(val)}
              options={[
                { label: "English", value: "en", icon: "globe" },
                { label: "Hindi", value: "hi", icon: "globe" },
                { label: "Tamil", value: "ta", icon: "globe" },
              ]}
            />
          }
        />
      </OptionGroup>

      <OptionGroup title="Notifications">
        <OptionItem
          title="Email notifications"
          description="Receive updates about your account activity"
          trailing={<Switch checked={emailNotifs} onCheckedChange={setEmailNotifs} />}
        />
      </OptionGroup>

      <Box display="flex" justify="end">
        <Button>Save changes</Button>
      </Box>
    </Box>
  );
}`,
  },

  "sidebar-layout": {
    title: "App Shell with Sidebar + Header + Content",
    description:
      "Full application shell using SidebarProvider + Sidebar. Only the main content area scrolls; " +
      "outer shell is overflow-hidden with minH=0 on flex children that scroll. Prefer AppShell if your " +
      "project exposes one; otherwise compose as below.",
    components: ["SidebarProvider", "Sidebar", "Header", "Box"],
    code: `"use client";

import { SidebarProvider, Sidebar, Header, Box } from "@sarvam/tatva";
import Link from "next/link";
import { usePathname } from "next/navigation";

const menuItems = [
  {
    title: "Main",
    items: [
      { label: "Dashboard", icon: "home", href: "/dashboard" },
      { label: "Analytics", icon: "chart-bar", href: "/analytics" },
      { label: "Users", icon: "users", href: "/users" },
      { label: "Settings", icon: "settings", href: "/settings" },
    ],
  },
];

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();

  return (
    <SidebarProvider>
      <Box display="flex" minH="screen" overflow="hidden" bg="surface-primary">
        <Sidebar
          menuItems={menuItems}
          activePath={pathname}
          linkComponent={Link}
          header={{ logo: "/logo.svg" }}
          profile={{
            name: "John Doe",
            email: "john@example.com",
            avatar: "/avatar.jpg",
          }}
        />
        <Box display="flex" direction="column" grow minH="0" m={4} rounded="lg" bg="surface-secondary" overflow="hidden">
          <Header type="main" left={{ title: "Dashboard" }} />
          <Box as="main" grow minH="0" overflow="auto" p={12}>
            {children}
          </Box>
        </Box>
      </Box>
    </SidebarProvider>
  );
}`,
  },

  "sheet-detail-view": {
    title: "Sheet (Slide-over) with Detail Form",
    description: "Side panel for viewing/editing entity details without leaving the current page.",
    components: ["Sheet", "Input", "Select", "Button", "Box", "Text"],
    code: `"use client";

import { Sheet, Box, Input, Select, Button, Text } from "@sarvam/tatva";
import { useForm, Controller } from "react-hook-form";

interface UserDetailSheetProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  user: { name: string; email: string; role: string } | null;
  onSave: (data: any) => Promise<void>;
}

export function UserDetailSheet({ open, onOpenChange, user, onSave }: UserDetailSheetProps) {
  const { control, handleSubmit, formState: { isSubmitting } } = useForm({
    values: user ?? { name: "", email: "", role: "viewer" },
  });

  return (
    <Sheet
      open={open}
      onOpenChange={onOpenChange}
      title="Edit User"
      description="Update user details and role"
      actions={[
        { label: "Cancel", variant: "outline", onClick: () => onOpenChange(false) },
        { label: "Save", onClick: handleSubmit(onSave), isLoading: isSubmitting },
      ]}
    >
      <Box display="flex" direction="column" gap={10}>
        <Controller
          name="name"
          control={control}
          render={({ field }) => <Input {...field} label="Name" />}
        />
        <Controller
          name="email"
          control={control}
          render={({ field }) => <Input {...field} label="Email" type="email" />}
        />
        <Controller
          name="role"
          control={control}
          render={({ field }) => (
            <Select
              {...field}
              label="Role"
              options={[
                { label: "Admin", value: "admin" },
                { label: "Editor", value: "editor" },
                { label: "Viewer", value: "viewer" },
              ]}
            />
          )}
        />
      </Box>
    </Sheet>
  );
}`,
  },

  "chat-interface": {
    title: "AI Chat Interface with Messages & Input",
    description: "Full chat UI using Tatva's AI Elements: conversation, messages, prompt input, and reasoning.",
    components: ["Conversation", "ConversationContent", "Message", "MessageContent", "PromptInput", "PromptInputTextarea", "PromptInputSubmit", "PromptInputBody"],
    code: `"use client";

import { useState } from "react";
import {
  Box,
  Conversation,
  ConversationContent,
  Message,
  MessageContent,
  PromptInput,
  PromptInputBody,
  PromptInputTextarea,
  PromptInputSubmit,
  PromptInputProvider,
} from "@sarvam/tatva";

interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
}

export function ChatInterface() {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const handleSend = async () => {
    if (!input.trim()) return;
    const userMsg: ChatMessage = { id: Date.now().toString(), role: "user", content: input };
    setMessages((prev) => [...prev, userMsg]);
    setInput("");
    setIsLoading(true);

    // Replace with your API call
    const response = await fetch("/api/chat", {
      method: "POST",
      body: JSON.stringify({ messages: [...messages, userMsg] }),
    });
    const data = await response.json();

    setMessages((prev) => [...prev, { id: (Date.now() + 1).toString(), role: "assistant", content: data.content }]);
    setIsLoading(false);
  };

  return (
    <Box display="flex" direction="column" minH="0" grow>
      <Conversation>
        <ConversationContent>
          {messages.map((msg) => (
            <Message key={msg.id} role={msg.role}>
              <MessageContent>{msg.content}</MessageContent>
            </Message>
          ))}
        </ConversationContent>
      </Conversation>

      <PromptInputProvider>
        <PromptInput>
          <PromptInputBody>
            <PromptInputTextarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Type a message..."
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  handleSend();
                }
              }}
            />
            <PromptInputSubmit onClick={handleSend} disabled={isLoading || !input.trim()} />
          </PromptInputBody>
        </PromptInput>
      </PromptInputProvider>
    </Box>
  );
}`,
  },

  "empty-loading-error-states": {
    title: "Data Page States (Loading, Error, Empty, Content)",
    description:
      "Required four-state pattern for any page that loads data. Page Header always stays mounted — " +
      "branch loading/error/empty/content BELOW it. EmptyState requires imageSrc or imageSlot (prefer StitchAsset in imageSlot when a motif exists) and exactly two actions.",
    components: ["Skeleton", "EmptyState", "Alert", "Box", "Header"],
    code: `"use client";

import { Box, Skeleton, EmptyState, Alert, Header } from "@sarvam/tatva";

interface DataPageProps<T> {
  data: T[] | undefined;
  isLoading: boolean;
  error: Error | null;
  title: string;
  emptyHeading: string;
  emptyBody: string;
  emptyImageSrc: string;
  onCreate: () => void;
  onRetry?: () => void;
  children: (data: T[]) => React.ReactNode;
}

export function DataPage<T>({
  data,
  isLoading,
  error,
  title,
  emptyHeading,
  emptyBody,
  emptyImageSrc,
  onCreate,
  onRetry,
  children,
}: DataPageProps<T>) {
  return (
    <Box display="flex" direction="column" gap={12}>
      <Header
        type="main"
        left={{ title }}
        actions={[{ label: "Create", icon: "plus", onClick: onCreate }]}
      />

      {isLoading ? (
        <Box display="flex" direction="column" gap={10}>
          <Skeleton height={40} width="30%" />
          <Skeleton height={200} />
          <Skeleton height={200} />
        </Box>
      ) : error ? (
        <Alert
          variant="danger"
          title="Failed to load data"
          description={error.message}
          action={onRetry ? { label: "Retry", onClick: onRetry } : undefined}
        />
      ) : !data || data.length === 0 ? (
        <EmptyState
          heading={emptyHeading}
          body={emptyBody}
          imageSrc={emptyImageSrc}
          actions={[
            { children: "Learn more", variant: "outline", onClick: () => {} },
            { children: "Create", variant: "primary", onClick: onCreate },
          ]}
        />
      ) : (
        children(data)
      )}
    </Box>
  );
}`,
  },

  "login-page": {
    title: "Login / Auth Page",
    description: "Public authentication page with form, no sidebar, centered layout.",
    components: ["Input", "Button", "Box", "Text", "Checkbox"],
    code: `"use client";

import { useForm, Controller } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { Box, Input, Button, Text, Checkbox } from "@sarvam/tatva";
import Link from "next/link";

const schema = z.object({
  email: z.string().email("Please enter a valid email"),
  password: z.string().min(8, "Password must be at least 8 characters"),
  rememberMe: z.boolean(),
});

type LoginValues = z.infer<typeof schema>;

export function LoginPage() {
  const { control, handleSubmit, formState: { errors, isSubmitting } } = useForm<LoginValues>({
    resolver: zodResolver(schema),
    defaultValues: { email: "", password: "", rememberMe: false },
  });

  const onSubmit = async (data: LoginValues) => {
    // Call your auth API
    console.log(data);
  };

  return (
    <Box
      display="flex"
      align="center"
      justify="center"
      minH="screen"
      bg="secondary"
    >
      <Box display="flex" direction="column" gap={12} w={210} p={12}>
        <Box display="flex" direction="column" gap={2}>
          <Text variant="heading-lg">Welcome back</Text>
          <Text variant="body-md" tone="secondary">
            Sign in to your account to continue
          </Text>
        </Box>

        <form onSubmit={handleSubmit(onSubmit)}>
          <Box display="flex" direction="column" gap={10}>
            <Controller
              name="email"
              control={control}
              render={({ field }) => (
                <Input
                  {...field}
                  label="Email"
                  placeholder="you@example.com"
                  type="email"
                  size="md"
                  error={errors.email?.message}
                />
              )}
            />
            <Controller
              name="password"
              control={control}
              render={({ field }) => (
                <Input
                  {...field}
                  label="Password"
                  type="password"
                  size="md"
                  error={errors.password?.message}
                />
              )}
            />
            <Box display="flex" justify="between" align="center" gap={2}>
              <Controller
                name="rememberMe"
                control={control}
                render={({ field }) => (
                  <Checkbox
                    checked={field.value}
                    onCheckedChange={field.onChange}
                    label="Remember me"
                  />
                )}
              />
              <Link href="/forgot-password">
                <Text variant="body-sm" tone="brand">Forgot password?</Text>
              </Link>
            </Box>
            <Button type="submit" width="full" size="md" isLoading={isSubmitting}>
              Sign in
            </Button>
          </Box>
        </form>

        <Box display="flex" justify="center" gap={2}>
          <Text variant="body-sm" tone="secondary">Don't have an account?</Text>
          <Link href="/signup">
            <Text variant="body-sm" tone="brand">Create one</Text>
          </Link>
        </Box>
      </Box>
    </Box>
  );
}`,
  },

  "tabs-with-content": {
    title: "Tabbed Content Sections",
    description:
      "Page with one level of Tabs switching peer content panels. Never nest tabs. " +
      "Controls only affect content below them.",
    components: ["Tabs", "Box", "Header"],
    code: `"use client";

import { useState } from "react";
import { Box, Header, Tabs } from "@sarvam/tatva";
import type { TabItem } from "@sarvam/tatva";

const tabs: TabItem[] = [
  { id: "overview", label: "Overview" },
  { id: "analytics", label: "Analytics" },
  { id: "settings", label: "Settings" },
];

export function ProjectPage() {
  const [activeTab, setActiveTab] = useState("overview");

  return (
    <Box display="flex" direction="column" gap={12}>
      <Header type="main" left={{ title: "Project Alpha" }} />
      <Tabs
        items={tabs}
        value={activeTab}
        onValueChange={setActiveTab}
      />
      <Box>
        {activeTab === "overview" && <OverviewContent />}
        {activeTab === "analytics" && <AnalyticsContent />}
        {activeTab === "settings" && <SettingsContent />}
      </Box>
    </Box>
  );
}`,
  },

  "time-availability-range": {
    title: "Time Availability Range (from → to)",
    description:
      "Two TimePickers for a 12h AM/PM hours window. Values stay HH:mm (24h). Pair with react-hook-form + zod when validating end > start.",
    components: ["TimePicker", "Box", "Icon", "Text", "Button"],
    code: `"use client";

import { useForm, Controller } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { Box, TimePicker, Icon, Text, Button } from "@sarvam/tatva";

const schema = z
  .object({
    from: z.string().regex(/^\\d{2}:\\d{2}$/, "Pick a start time"),
    to: z.string().regex(/^\\d{2}:\\d{2}$/, "Pick an end time"),
  })
  .refine((v) => v.to > v.from, {
    message: "End time must be after start time",
    path: ["to"],
  });

type FormValues = z.infer<typeof schema>;

export function AvailabilityHoursForm({
  onSubmit,
}: {
  onSubmit: (data: FormValues) => void;
}) {
  const {
    control,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: { from: "09:00", to: "16:00" },
  });

  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <Box display="flex" direction="column" gap={10}>
        <Text variant="label-md" tone="secondary">
          Hours *
        </Text>
        <Box display="flex" align="center" gap={4}>
          <Box grow>
            <Controller
              name="from"
              control={control}
              render={({ field }) => (
                <TimePicker
                  value={field.value}
                  onValueChange={field.onChange}
                  error={errors.from?.message}
                />
              )}
            />
          </Box>
          <Icon name="arrow-right" size="xs" tone="secondary" />
          <Box grow>
            <Controller
              name="to"
              control={control}
              render={({ field }) => (
                <TimePicker
                  value={field.value}
                  onValueChange={field.onChange}
                  error={errors.to?.message}
                />
              )}
            />
          </Box>
        </Box>
        <Button type="submit" isLoading={isSubmitting}>
          Save hours
        </Button>
      </Box>
    </form>
  );
}`,
  },
};

// ─── Tool Definition ─────────────────────────────────────────────────────────

const patternNames = Object.keys(PATTERNS);

export const definition = {
  name: "get_patterns",
  description:
    "Returns full, copy-paste-ready code patterns that combine multiple Tatva components " +
    "into production-ready compositions. Use these as starting templates — they show how " +
    "components work together in real-world scenarios.\n\n" +
    "Available patterns: " + patternNames.join(", ") + "\n\n" +
    "Pass pattern names to get their full code, or pass no specific patterns to get the index.",
  schema: v.object({
    patterns: v.pipe(
      v.array(v.string()),
      v.description(
        "Array of pattern names to fetch. Available: " + patternNames.join(", ") +
        '. Pass ["all"] to get everything, or an empty array to get the index only.'
      )
    ),
    projectPath: v.pipe(
      v.string(),
      v.description(
        "Absolute path to the project root, e.g. /Users/you/my-app. Used for analytics."
      )
    ),
  }),
};

export async function execute({ patterns }) {
  // If empty array or not provided, return index
  if (!patterns || patterns.length === 0) {
    const index = Object.entries(PATTERNS).map(([key, p]) => (
      `- **${key}**: ${p.title}\n  ${p.description}\n  Components: ${p.components.join(", ")}`
    )).join("\n\n");

    return {
      content: [{
        type: "text",
        text: `## Available Patterns (${patternNames.length})\n\n${index}\n\n---\n\nCall \`get_patterns\` with the pattern names you need, e.g. \`{ "patterns": ["form-with-validation", "data-table-with-filters"] }\``,
      }],
    };
  }

  // If "all" is passed, return everything
  const keys = patterns.includes("all") ? patternNames : patterns;

  const results = keys.map((key) => {
    const pattern = PATTERNS[key];
    if (!pattern) return `## ❌ ${key}\n\nPattern not found. Available: ${patternNames.join(", ")}`;

    return `## ${pattern.title}\n\n${pattern.description}\n\n**Components used:** ${pattern.components.join(", ")}\n\n\`\`\`tsx\n${pattern.code}\n\`\`\``;
  });

  return {
    content: [{ type: "text", text: results.join("\n\n---\n\n") }],
  };
}
