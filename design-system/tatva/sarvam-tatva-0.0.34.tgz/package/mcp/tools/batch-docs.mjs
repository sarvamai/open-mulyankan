/**
 * get_component_docs tool
 *
 * Fetches Storybook documentation for multiple Tatva components in a single
 * MCP call, then formats it into a compact LLM-friendly shape (props + one
 * example + anti-patterns) instead of dumping raw Storybook MDX/stories.
 *
 * Requires server.mjs to inject { callStorybookTool } via the second argument.
 */

import * as v from "valibot";
import { getEnrichment } from "./component-metadata.mjs";
import { formatAgentDocs } from "../lib/format-agent-docs.mjs";

export const definition = {
  name: "get_component_docs",
  description:
    "Fetches full documentation (props, variants, usage examples) for multiple Tatva components " +
    "in a single call. Pass component names like [\"Button\", \"Input\", \"Dialog\"] — no need to " +
    "call list-all-documentation first. Always use this instead of get-documentation. " +
    "Pass ALL components you need for the current task at once.",
  schema: v.object({
    components: v.pipe(
      v.array(v.string()),
      v.description(
        'Array of component names or story IDs, e.g. ["Button", "Input", "Dialog"]. ' +
          "Names are matched case-insensitively against the component library."
      )
    ),
    projectPath: v.pipe(
      v.string(),
      v.description(
        "Absolute path to the project root, e.g. /Users/you/my-app. " +
          "Used for analytics — always pass this."
      )
    ),
  }),
};

export async function execute({ components }, { callStorybookTool }) {
  if (!Array.isArray(components) || components.length === 0) {
    return {
      isError: true,
      content: [
        {
          type: "text",
          text: 'Error: components must be a non-empty array of component names, e.g. ["Button", "Input"].',
        },
      ],
    };
  }

  // Fetch the full component list so we can resolve names → story IDs.
  // list-all-documentation returns lines like: "- Button (components-button-button)"
  let allDocs = [];
  try {
    const listResult = await callStorybookTool("list-all-documentation", {});
    const text = listResult?.content?.[0]?.text ?? "";
    allDocs = text
      .split("\n")
      .map((line) => {
        const match = line.match(/^\s*-\s+(.+?)\s+\(([^)]+)\)/);
        if (match) return { name: match[1].trim().toLowerCase(), id: match[2].trim() };
        return null;
      })
      .filter(Boolean);
  } catch {
    // If listing fails, fall through and try the name as a raw ID
  }

  const results = await Promise.all(
    components.map(async (nameOrId) => {
      const id = resolveId(nameOrId, allDocs);
      try {
        const result = await callStorybookTool("get-documentation", { id });
        const text =
          result?.content?.[0]?.text ?? `No documentation found for "${nameOrId}".`;
        const enrichment = getEnrichment(nameOrId) ?? "";
        return formatAgentDocs(text, { name: nameOrId, enrichment });
      } catch (err) {
        return `## ${nameOrId}\n\nError fetching docs: ${err.message}`;
      }
    })
  );

  return {
    content: [{ type: "text", text: results.join("\n\n---\n\n") }],
  };
}

/**
 * Given a component name ("Button") or a story ID ("components-button-button"),
 * return the best matching story ID from the parsed docs list.
 *
 * allDocs entries: { name: string (lowercase), id: string }
 *
 * Matching priority:
 *   1. Exact story ID — already in the list
 *   2. Exact component name match (case-insensitive)
 *   3. Component name contains the needle, or needle contains the name
 *   4. Story ID contains the needle
 *   5. Fall back to the original value (Storybook will return a useful error)
 */
function resolveId(nameOrId, allDocs) {
  const needle = nameOrId.toLowerCase().replace(/[\s-]+/g, "");

  const exactId = allDocs.find((e) => e.id === nameOrId);
  if (exactId) return exactId.id;

  const exactName = allDocs.find((e) => e.name.replace(/[\s-]+/g, "") === needle);
  if (exactName) return exactName.id;

  const partial = allDocs.find(
    (e) =>
      e.name.replace(/[\s-]+/g, "").includes(needle) ||
      needle.includes(e.name.replace(/[\s-]+/g, ""))
  );
  if (partial) return partial.id;

  const idMatch = allDocs.find((e) => e.id.replace(/-/g, "").includes(needle));
  if (idMatch) return idMatch.id;

  return nameOrId;
}
