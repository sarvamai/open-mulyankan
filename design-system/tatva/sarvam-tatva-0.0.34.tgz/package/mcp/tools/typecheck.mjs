/**
 * run_typecheck tool
 *
 * Runs TypeScript type-checking on the project and returns errors.
 * This enables a self-healing loop: the agent writes code, runs typecheck,
 * sees errors, and fixes them — instead of guessing and moving on.
 *
 * Also supports checking a single file for faster feedback.
 */

import { execFile } from "node:child_process";
import { access, constants } from "node:fs/promises";
import { join } from "node:path";
import * as v from "valibot";

export const definition = {
  name: "run_typecheck",
  description:
    "Runs TypeScript type-checking on the project (or a specific file) and returns any errors. " +
    "Use this after writing code to verify it compiles correctly. If there are errors, " +
    "re-check the component docs via get_component_docs and fix the issues.\n\n" +
    "Returns: list of TypeScript errors with file, line, and message. Empty = no errors.",
  schema: v.object({
    projectPath: v.pipe(
      v.string(),
      v.description(
        "Absolute path to the project root (where tsconfig.json lives), e.g. /Users/you/my-app"
      )
    ),
    file: v.pipe(
      v.string(),
      v.description(
        "Optional: relative path to a specific file to check, e.g. 'src/app/page.tsx'. " +
        "If empty, checks the entire project. Checking a single file is faster."
      )
    ),
  }),
};

async function findTsc(projectPath) {
  // Try project-local tsc first
  const localTsc = join(projectPath, "node_modules", ".bin", "tsc");
  try {
    await access(localTsc, constants.X_OK);
    return localTsc;
  } catch {
    // Fall back to npx tsc
    return null;
  }
}

function runCommand(cmd, args, cwd) {
  return new Promise((resolve) => {
    execFile(cmd, args, { cwd, timeout: 60_000, maxBuffer: 1024 * 1024 * 5 }, (error, stdout, stderr) => {
      resolve({ code: error?.code ?? 0, stdout: stdout ?? "", stderr: stderr ?? "" });
    });
  });
}

export async function execute({ projectPath, file }) {
  // Verify project exists
  try {
    await access(join(projectPath, "tsconfig.json"), constants.R_OK);
  } catch {
    return {
      isError: true,
      content: [{
        type: "text",
        text: `Error: No tsconfig.json found at ${projectPath}. Make sure projectPath points to the project root.`,
      }],
    };
  }

  const tscPath = await findTsc(projectPath);
  let cmd, args;

  if (tscPath) {
    cmd = tscPath;
    args = ["--noEmit", "--pretty", "false"];
  } else {
    cmd = "npx";
    args = ["tsc", "--noEmit", "--pretty", "false"];
  }

  // If checking a specific file, add it
  if (file && file.trim()) {
    args.push("--noEmit", file.trim());
    // For single file check, we need --skipLibCheck and explicit include
    args.push("--skipLibCheck");
  }

  const { code, stdout, stderr } = await runCommand(cmd, args, projectPath);

  const output = (stdout + "\n" + stderr).trim();

  if (code === 0 || !output) {
    return {
      content: [{
        type: "text",
        text: file
          ? `✅ No TypeScript errors in ${file}`
          : "✅ No TypeScript errors found in the project.",
      }],
    };
  }

  // Parse errors into a structured format
  const lines = output.split("\n").filter((l) => l.trim());
  const errors = [];
  for (const line of lines) {
    // Format: src/app/page.tsx(12,5): error TS2322: Type 'string' is not assignable...
    const match = line.match(/^(.+?)\((\d+),(\d+)\):\s*error\s+(TS\d+):\s*(.+)$/);
    if (match) {
      errors.push({
        file: match[1],
        line: parseInt(match[2]),
        col: parseInt(match[3]),
        code: match[4],
        message: match[5],
      });
    }
  }

  if (errors.length === 0) {
    // Couldn't parse structured errors, return raw output
    return {
      content: [{
        type: "text",
        text: `## TypeScript Errors\n\n\`\`\`\n${output.slice(0, 3000)}\n\`\`\`\n\n**Fix:** Re-check component props via \`get_component_docs\` for any components with errors.`,
      }],
    };
  }

  // Group by file
  const byFile = {};
  for (const err of errors) {
    if (!byFile[err.file]) byFile[err.file] = [];
    byFile[err.file].push(err);
  }

  let response = `## TypeScript Errors (${errors.length})\n\n`;
  for (const [filePath, fileErrors] of Object.entries(byFile)) {
    response += `### ${filePath}\n\n`;
    for (const err of fileErrors) {
      response += `- **Line ${err.line}:** ${err.message} (${err.code})\n`;
    }
    response += "\n";
  }

  response += "---\n\n";
  response += "**How to fix:**\n";
  response += "1. Call `get_component_docs` for any Tatva components mentioned in the errors\n";
  response += "2. Check prop names and types against the documentation\n";
  response += "3. Fix the errors and run `run_typecheck` again to verify\n";

  return {
    content: [{ type: "text", text: response }],
  };
}
