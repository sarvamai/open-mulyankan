/**
 * list_components tool
 *
 * Returns every available Tatva component name so agents know what's in the
 * library before deciding which docs to fetch.
 *
 * Requires server.mjs to inject { callStorybookTool } via the second argument.
 */

import * as v from "valibot";
import { isRealComponentName } from "../lib/format-agent-docs.mjs";

export const definition = {
  name: "list_components",
  description:
    "Returns the full list of available @sarvam/tatva components. " +
    "Call this first to discover what components exist (e.g. ChatInput, BarChart, DataTable) " +
    "before calling get_component_docs for the ones you need.",
  schema: v.object({
    projectPath: v.pipe(
      v.string(),
      v.description(
        "Absolute path to the project root, e.g. /Users/you/my-app. " +
          "Used for analytics — always pass this."
      )
    ),
  }),
};

export async function execute(_args, { callStorybookTool }) {
  try {
    const listResult = await callStorybookTool("list-all-documentation", {});
    const text = listResult?.content?.[0]?.text ?? "";

    const components = text
      .split("\n")
      .map((line) => {
        const match = line.match(/^\s*-\s+(.+?)\s+\(([^)]+)\)/);
        if (match) return match[1].trim();
        return null;
      })
      .filter(Boolean)
      .filter(isRealComponentName);

    if (components.length === 0) {
      return {
        content: [{ type: "text", text: "No components found. Is Storybook running?" }],
      };
    }

    return {
      content: [
        {
          type: "text",
          text:
            `## Available Tatva Components (${components.length})\n\n` +
            `${components.map((c) => `- ${c}`).join("\n")}\n\n` +
            `## Recommended Workflow\n\n` +
            `1. **Plan:** Call \`find_components_for_task\` with a description of what you're building\n` +
            `2. **Get patterns:** Call \`get_patterns\` for copy-paste templates\n` +
            `3. **Fetch docs:** Call \`get_component_docs\` with component names: \`{ "components": ["Button", "Input"], "projectPath": "/path/to/project" }\`\n` +
            `4. **Build & verify:** Write code, then call \`run_typecheck\` to verify\n\n` +
            `IMPORTANT: Pass ALL components you need in one \`get_component_docs\` call — never fetch one at a time.`,
        },
      ],
    };
  } catch (err) {
    return {
      isError: true,
      content: [{ type: "text", text: `Error listing components: ${err.message}` }],
    };
  }
}
