/**
 * setup_tatva tool
 *
 * Returns:
 *  1. A short bash script for the deterministic, state-free parts:
 *     .npmrc, IDE rules (curl), create-next-app (new projects), npm install.
 *  2. Step-by-step instructions for everything that depends on project state
 *     (Tailwind config, CSS import, layout providers) so the agent can read
 *     the actual files and make surgical edits rather than overwriting wholesale.
 */

import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import * as v from "valibot";

const __dirname = dirname(fileURLToPath(import.meta.url));
const PKG_ROOT = join(__dirname, "..", "..");
void PKG_ROOT; // used only by server.mjs for the /mcp/rules endpoint

export const definition = {
  name: "setup_tatva",
  description:
    "Sets up @sarvam/tatva in a project, or updates rules if already installed. " +
    "Call this if @sarvam/tatva is NOT in package.json, OR if the local rules are outdated (rulesVersion mismatch). " +
    "Returns (1) a bash script to run immediately for registry + rules + scaffold/install, " +
    "and (2) step-by-step instructions to follow for Tailwind, CSS, and provider setup. " +
    "For empty directories: scaffolds a complete Next.js app. " +
    "For existing projects: idempotently fills any missing setup steps. " +
    "Run the bash script first, then follow the step-by-step instructions to configure Tailwind, CSS imports, and providers.",
  schema: v.object({
    projectRoot: v.pipe(
      v.string(),
      v.description(
        "Absolute path to the project root (e.g. /Users/you/my-app). " +
        "Check the directory first: if it is empty or has no package.json, pass isEmpty=true."
      )
    ),
    ide: v.pipe(
      v.string(),
      v.description('Which IDE rules to write: "cursor", "claude", or "both".')
    ),
    isEmpty: v.pipe(
      v.string(),
      v.description(
        'Pass "true" if the directory is empty / has no package.json (new project). ' +
        'Pass "false" for existing projects.'
      )
    ),
  }),
};

export async function execute({ projectRoot, ide, isEmpty }, _context, { mcpServerUrl } = {}) {
  const isNew = isEmpty === "true" || isEmpty === true;
  const rulesBaseUrl = (mcpServerUrl ?? "https://tatva.sarvam.ai").replace(/\/$/, "");
  const rulesSnippet = ideRulesSnippet(ide, rulesBaseUrl);

  const bashScript = isNew
    ? buildNewProjectBash(projectRoot, rulesSnippet)
    : buildExistingProjectBash(projectRoot, rulesSnippet);

  const setupInstructions = isNew
    ? newProjectInstructions()
    : existingProjectInstructions();

  return {
    content: [{
      type: "text",
      text: buildResponse(bashScript, setupInstructions),
    }],
  };
}

// ─── Response builder ─────────────────────────────────────────────────────────

function buildResponse(bashScript, setupInstructions) {
  return `## Step 1 — Run this bash script

Run the entire block below in one terminal call. It handles registry config, IDE rules, and package installation.

\`\`\`bash
${bashScript}
\`\`\`

---

## Step 2 — Complete setup (read files and apply these changes)

After the script exits, make the following changes to the project. Read each file first, then edit surgically — do not overwrite.

${setupInstructions}

---

## Step 3 — Done

Once setup is complete:
1. Call \`get_component_docs\` with all components needed for this task (e.g. \`["Button", "Input", "Dialog"]\`)
2. Build the UI

Design system rules are loaded automatically from the IDE rules file installed in step 1.`;
}

// ─── Bash snippets (deterministic, no project-state inspection needed) ────────

function ideRulesSnippet(ide, rulesBaseUrl) {
  const parts = [];
  parts.push(
    `# If this repo already owns agent rules via AGENTS.md + rules/ (authored router),`,
    `# skip the curl below — do not overwrite CLAUDE.md / AGENTS.md.`,
    ``
  );
  if (ide === "cursor" || ide === "both") {
    parts.push(
      `# IDE rules (Cursor)`,
      `mkdir -p .cursor/rules`,
      `curl -fsSL "${rulesBaseUrl}/mcp/rules" > .cursor/rules/tatva-frontend.mdc`,
      ``
    );
  }
  if (ide === "claude" || ide === "both") {
    parts.push(
      `# IDE rules (Claude)`,
      `curl -fsSL "${rulesBaseUrl}/mcp/rules/claude" > CLAUDE.md`,
      ``
    );
  }
  return parts.join("\n");
}

function buildNewProjectBash(projectRoot, rulesSnippet) {
  return `set -e
cd "${projectRoot}"

# ── Registry (.npmrc written AFTER scaffold to avoid registry conflicts) ───────

# ── IDE rules ─────────────────────────────────────────────────────────────────
${rulesSnippet}
# ── Scaffold Next.js ──────────────────────────────────────────────────────────
# No .npmrc yet — create-next-app must resolve from public npm
npx create-next-app@latest . --typescript --tailwind --app --src-dir --import-alias "@/*" --yes

# ── Registry (write now, after scaffold) ──────────────────────────────────────
printf '@sarvam:registry=https://asia-south1-npm.pkg.dev/saas-prod-457804/design-system/\\n' > .npmrc

# ── Install Tatva + peers ─────────────────────────────────────────────────────
npm install @sarvam/tatva @hugeicons/react react-hook-form zod sonner --legacy-peer-deps

npm list @sarvam/tatva --depth=0
echo "✅ Install complete — continue with Step 2"`;
}

function buildExistingProjectBash(projectRoot, rulesSnippet) {
  return `set -e
cd "${projectRoot}"

# ── Registry ──────────────────────────────────────────────────────────────────
printf '@sarvam:registry=https://asia-south1-npm.pkg.dev/saas-prod-457804/design-system/\\n' > .npmrc
echo "✓ .npmrc written"

# ── IDE rules ─────────────────────────────────────────────────────────────────
${rulesSnippet}
# ── Install Tatva if missing ──────────────────────────────────────────────────
if grep -q '"@sarvam/tatva"' package.json 2>/dev/null; then
  echo "✓ @sarvam/tatva already installed"
else
  npm install @sarvam/tatva @hugeicons/react react-hook-form zod sonner --legacy-peer-deps
fi

npm list @sarvam/tatva --depth=0
echo "✅ Install complete — continue with Step 2"`;
}

// ─── Setup instructions (returned for agent to follow using file tools) ────────

function newProjectInstructions() {
  return `### 1. Detect Tailwind version

Run: \`node -e "console.log(require('./node_modules/tailwindcss/package.json').version)"\`

---

### 2. Update \`src/app/globals.css\`

Replace or update the CSS file based on the detected version:

**Tailwind v4** — simpler, no config file needed:
\`\`\`css
@import "tailwindcss";
@import "@sarvam/tatva/theme.css";
@source "../../node_modules/@sarvam/tatva/dist/**/*.{js,mjs}";
\`\`\`
\`theme.css\` replaces both \`styles.css\` and the Tailwind preset — it declares all tokens
via \`@theme\` so v4 generates every \`p-tatva-*\`, \`bg-tatva-*\`, etc. class statically.
The \`@source\` path uses \`../../\` because \`globals.css\` lives at \`src/app/globals.css\`
(two levels deep from the project root where \`node_modules\` is).
No safelist needed. No \`tailwind.config.ts\` needed.

**Tailwind v3** — preset-based:
\`\`\`css
@import "@sarvam/tatva/styles.css";

@tailwind base;
@tailwind components;
@tailwind utilities;
\`\`\`

---

### 3. Update \`tailwind.config.ts\` (Tailwind v3 only — skip for v4)

Open the file and apply these changes:

\`\`\`ts
// eslint-disable-next-line @typescript-eslint/no-require-imports
const tatvaPreset = require("@sarvam/tatva/tailwind-preset");

const config: Config = {
  presets: [tatvaPreset],
  content: [
    // ... keep existing paths ...
    "./node_modules/@sarvam/tatva/dist/**/*.{js,mjs}",
  ],
  darkMode: "class",
};
\`\`\`

Also install the container-queries plugin for v3:
\`\`\`bash
npm install @tailwindcss/container-queries --save-dev --legacy-peer-deps
\`\`\`

---

### 4. Update \`src/app/layout.tsx\`

Wrap the \`<body>\` children with \`<AnimationProvider>\` and \`<TooltipProvider>\`, and add \`<Toaster>\`:

\`\`\`tsx
import { AnimationProvider, TooltipProvider } from "@sarvam/tatva";
import { Toaster } from "sonner";

// Inside <body>:
<AnimationProvider>
  <TooltipProvider>
    {children}
    <Toaster position="bottom-right" />
  </TooltipProvider>
</AnimationProvider>
\`\`\`

**Always include \`AnimationProvider\` in the default setup** — it is Tatva's micro-interaction layer (count-up metrics, flowing nav focus, chart hover-dim, staggered tables, bounce toggles) and is part of the standard layout for every app. It ships inside \`@sarvam/tatva\` (no separate install). It is a client component, so it works directly inside a server \`layout.tsx\`. Without it, every component renders static; mounting it once at the root turns motion on app-wide. Reduced-motion is respected automatically and loaders always animate, so it is always safe to include. Props: \`enabled\`, \`reducedMotion\` (\`"user" | "always" | "never"\`), \`tokens\`.

---

### 5. Verify

Run \`npm run dev\` — if the dev server starts without errors, setup is complete.`;
}

function existingProjectInstructions() {
  return `### 1. Detect Tailwind version

Run: \`node -e "console.log(require('./node_modules/tailwindcss/package.json').version)"\`

---

### 2. Check the main CSS file (globals.css or equivalent)

Open it and check if \`@sarvam/tatva\` is already imported. If not:

**Tailwind v4** — replace its contents (or add if using CSS-only Tailwind):
\`\`\`css
@import "tailwindcss";
@import "@sarvam/tatva/theme.css";
@source "../../node_modules/@sarvam/tatva/dist/**/*.{js,mjs}";
\`\`\`
\`theme.css\` handles everything — tokens, styles, animations. No config file needed.
The \`@source\` path assumes \`globals.css\` is at \`src/app/globals.css\`. If it is at \`app/globals.css\` instead, use \`../node_modules/\` (one level up).

**Tailwind v3** — add as the very first line, before any \`@tailwind\` directives:
\`\`\`css
@import "@sarvam/tatva/styles.css";
\`\`\`

---

### 3. Check \`tailwind.config.ts\` (Tailwind v3 only — skip for v4)

If it doesn't already reference \`tatva\`, add:

\`\`\`ts
// eslint-disable-next-line @typescript-eslint/no-require-imports
const tatvaPreset = require("@sarvam/tatva/tailwind-preset");

const config: Config = {
  presets: [tatvaPreset],
  content: [
    // ... existing paths ...
    "./node_modules/@sarvam/tatva/dist/**/*.{js,mjs}",
  ],
};
\`\`\`

Also install the container-queries plugin if not present:
\`\`\`bash
npm install @tailwindcss/container-queries --save-dev --legacy-peer-deps
\`\`\`

---

### 4. Check \`layout.tsx\` (or equivalent root layout/provider)

If \`TooltipProvider\` from \`@sarvam/tatva\` is not wrapping the app, add it — and **always wrap everything in \`AnimationProvider\`** (standard for every app) to enable Tatva's motion layer:
\`\`\`tsx
import { AnimationProvider, TooltipProvider } from "@sarvam/tatva";
import { Toaster } from "sonner";

<AnimationProvider>
  <TooltipProvider>
    {children}
    <Toaster position="bottom-right" />
  </TooltipProvider>
</AnimationProvider>
\`\`\`

Always add \`AnimationProvider\`: mounting it turns on micro-interactions app-wide (count-up, flowing nav focus, chart hover-dim, staggered tables). It ships inside \`@sarvam/tatva\` (no separate install) and is safe by default — reduced-motion is respected automatically and loaders always animate. Props: \`enabled\`, \`reducedMotion\`, \`tokens\`. If the app already had Tatva set up before this layer existed, adding this one wrapper is all that's needed to enable it.

---

### 5. Verify

Run \`npm run dev\` — if the dev server starts without errors, setup is complete.`;
}