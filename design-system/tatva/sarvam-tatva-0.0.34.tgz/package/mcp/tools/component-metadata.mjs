/**
 * Component Metadata — enrichment data appended to get_component_docs responses.
 *
 * For each component, this provides:
 * - realWorldExamples: Production-ready code snippets showing the component in context
 * - relatedComponents: What to pair with and when to use alternatives
 * - antiPatterns: Common mistakes agents make
 * - importPath: Exact import statement
 */

export const COMPONENT_METADATA = {
  Button: {
    importPath: `import { Button } from "@sarvam/tatva";`,
    relatedComponents: ["Dialog (for confirmation flows)", "Box (for spacing/margins)", "Tooltip (for icon-only buttons)"],
    antiPatterns: [
      "❌ Don't use more than one `variant=\"primary\"` button per page section",
      "❌ Don't add `className` for margins — wrap in `<Box>` instead",
      "❌ Don't set both `isLoading` and `disabled` — isLoading auto-disables",
      "❌ Don't pass JSX as `children` — only plain text strings",
      "❌ Don't use icon-only buttons without `tooltip` (accessibility)",
    ],
    realWorldExamples: [
      {
        title: "Form submit with loading",
        code: `<Button type="submit" width="full" isLoading={isPending}>Save Changes</Button>`,
      },
      {
        title: "Icon-only action button",
        code: `<Button variant="ghost" size="sm" icon="trash" tooltip="Delete item" />`,
      },
      {
        title: "Destructive action in dialog footer",
        code: `<Dialog actions={[\n  { label: "Cancel", variant: "outline", onClick: onCancel },\n  { label: "Delete", variant: "destructive", onClick: onDelete, isLoading: isDeleting },\n]} />`,
      },
      {
        title: "Button with right-arrow icon",
        code: `<Button icon="arrow-right" iconPosition="right">Continue</Button>`,
      },
    ],
  },

  Input: {
    importPath: `import { Input } from "@sarvam/tatva";`,
    relatedComponents: ["Select (for predefined choices)", "Textarea (for multi-line)", "TagInput (for multiple values)", "TimePicker (for time-only)"],
    antiPatterns: [
      "❌ Don't use uncontrolled — always use with react-hook-form Controller",
      "❌ Don't build custom error display — use the `error` prop",
      "❌ Don't use `placeholder` as a label replacement — always pass `label`",
    ],
    realWorldExamples: [
      {
        title: "Search input with icon",
        code: `<Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search..." icon="search" />`,
      },
      {
        title: "Form field with validation error",
        code: `<Controller\n  name="email"\n  control={control}\n  render={({ field }) => (\n    <Input {...field} label="Email" type="email" error={errors.email?.message} />\n  )}\n/>`,
      },
    ],
  },

  TimePicker: {
    importPath: `import { TimePicker } from "@sarvam/tatva";`,
    relatedComponents: [
      "DatePicker (for date + optional time)",
      "Select (for preset time lists)",
      "Box (for from→to ranges)",
    ],
    antiPatterns: [
      "❌ Don't pass 12h strings as `value` — always use `HH:mm` 24h",
      "❌ Don't build a custom time dropdown — use TimePicker",
      "❌ Don't use DatePicker when you only need time",
    ],
    realWorldExamples: [
      {
        title: "Controlled start time",
        code: `const [time, setTime] = useState("09:00");\n<TimePicker label="Start time" value={time} onValueChange={setTime} required />`,
      },
      {
        title: "Availability hours range",
        code: `<Box display="flex" align="center" gap={4}>\n  <Box grow><TimePicker value={from} onValueChange={setFrom} /></Box>\n  <Icon name="arrow-right" size="xs" tone="secondary" />\n  <Box grow><TimePicker value={to} onValueChange={setTo} /></Box>\n</Box>`,
      },
    ],
  },

  Table: {
    importPath: `import { Table } from "@sarvam/tatva";\nimport type { TableColumn } from "@sarvam/tatva";`,
    relatedComponents: [
      "Input (for search)",
      "EmptyState (required for no-data state)",
      "Badge (for status columns)",
      "Header (page chrome above the table)",
    ],
    antiPatterns: [
      "❌ Don't forget empty state — always handle `data.length === 0`",
      "❌ Don't use for < 3 items — use OptionGroup instead",
      "❌ Don't skip `getRowId` — it's required for proper key management",
      "❌ Don't remount Table on navigate-back / tab switch / loading toggles — update `data` / `isLoading` / `isRefetching` in place (unstable `key` or conditional unmount replays row stagger under AnimationProvider)",
      "❌ Don't use Pill — use Badge",
      "❌ Don't set column width via `style.width` on cell content — use `TableColumn.size` on the column (header) definition only",
      "❌ Don't wrap text cells in a bare `<div>` if you want truncate + tooltip — return a string/number or use accessorKey (native `truncate`)",
    ],
    realWorldExamples: [
      {
        title: "Typed columns with custom render",
        code: `const columns: TableColumn<User>[] = [\n  { id: "name", header: "Name", accessorKey: "name", enableSorting: true, size: 200 },\n  { id: "email", header: "Email", accessorKey: "email", size: 240 },\n  { id: "status", header: "Status", accessorKey: "status", size: 120, truncate: false, cell: ({ row }) => <Badge variant={row.original.status === "active" ? "green" : "default"} size="sm">{row.original.status}</Badge> },\n];\n\n<Table data={users} columns={columns} pageSize={10} getRowId={(r) => r.id} />`,
      },
    ],
  },

  Dialog: {
    importPath: `import { Dialog } from "@sarvam/tatva";`,
    relatedComponents: ["Sheet (for long forms or detail views)", "Button (trigger)", "toast (for post-action feedback)"],
    antiPatterns: [
      "❌ Don't use for long forms (> 5 fields) — use Sheet instead",
      "❌ Don't nest dialogs inside dialogs",
      "❌ Don't forget to handle async actions with isLoading on the action button",
    ],
    realWorldExamples: [
      {
        title: "Delete confirmation",
        code: `<Dialog\n  open={open}\n  onOpenChange={setOpen}\n  title="Delete project?"\n  description="This cannot be undone."\n  actions={[\n    { label: "Cancel", variant: "outline", onClick: () => setOpen(false) },\n    { label: "Delete", variant: "destructive", onClick: handleDelete, isLoading },\n  ]}\n/>`,
      },
      {
        title: "Marketing dialog with StitchAsset image",
        code: `import StitchAsset from "@/shared/stitch/components/StitchAsset";\n\n<Dialog\n  open={open}\n  onOpenChange={setOpen}\n  size="xxl"\n  imagePosition="left"\n  image={\n    <div className="relative h-[520px] w-full overflow-hidden rounded-tatva-md">\n      <StitchAsset config={introPattern} fill width={480} height={520} physics physicsScale={1.5} className="absolute inset-0" />\n    </div>\n  }\n  title="Welcome"\n  description="Get started with the product."\n  submitButtonText="Get started"\n  onSubmit={() => setOpen(false)}\n/>`,
      },
    ],
  },

  Sheet: {
    importPath: `import { Sheet } from "@sarvam/tatva";`,
    relatedComponents: ["Dialog (for simple confirmations)", "Input/Select (form fields inside)", "Button (actions)"],
    antiPatterns: [
      "❌ Don't use for simple yes/no confirmations — use Dialog",
      "❌ Don't forget actions array for the footer buttons",
    ],
    realWorldExamples: [
      {
        title: "Entity detail editor",
        code: `<Sheet\n  open={open}\n  onOpenChange={setOpen}\n  title="Edit User"\n  actions={[\n    { label: "Cancel", variant: "outline", onClick: () => setOpen(false) },\n    { label: "Save", onClick: handleSubmit(onSave), isLoading },\n  ]}\n>\n  <Box display="flex" direction="column" gap={10}>\n    <Controller name="name" control={control} render={({ field }) => <Input {...field} label="Name" />} />\n  </Box>\n</Sheet>`,
      },
    ],
  },

  MetricCard: {
    importPath: `import { MetricCard } from "@sarvam/tatva";`,
    relatedComponents: ["BarChart", "LineChart", "AreaChart", "Sparkline", "DonutChart (all charts go inside MetricCard)"],
    antiPatterns: [
      "❌ Never render a chart without a MetricCard wrapper",
      "❌ Don't use Card for KPI/stat displays — always MetricCard",
      "❌ Don't forget the `change` prop for trend indicators",
    ],
    realWorldExamples: [
      {
        title: "KPI with bar chart",
        code: `<MetricCard title="Revenue" value="$12,340" change={{ value: 12.5, direction: "up" }}>\n  <BarChart data={data} series={[{ key: "value", label: "Revenue" }]} height={120} />\n</MetricCard>`,
      },
      {
        title: "Stat with sparkline",
        code: `<MetricCard title="Active Users" value="1,247">\n  <Sparkline data={[120, 145, 132, 167, 189]} height={40} />\n</MetricCard>`,
      },
    ],
  },

  Select: {
    importPath: `import { Select } from "@sarvam/tatva";\nimport type { SelectOption } from "@sarvam/tatva";`,
    relatedComponents: ["Input (for free-text)", "RadioGroup (for < 5 visible options)", "TagInput (for multi-select)"],
    antiPatterns: [
      "❌ Don't build custom dropdowns — always use Select",
      "❌ Don't forget the `options` array with `{ label, value }` objects",
    ],
    realWorldExamples: [
      {
        title: "Role selector in a form",
        code: `<Controller\n  name="role"\n  control={control}\n  render={({ field }) => (\n    <Select\n      {...field}\n      label="Role"\n      options={[\n        { label: "Admin", value: "admin" },\n        { label: "Editor", value: "editor" },\n        { label: "Viewer", value: "viewer" },\n      ]}\n      error={errors.role?.message}\n    />\n  )}\n/>`,
      },
    ],
  },

  EmptyState: {
    importPath: `import { EmptyState } from "@sarvam/tatva";`,
    relatedComponents: [
      "Header (keep mounted above EmptyState)",
      "Table (use Table empty props for in-table empty)",
      "Button (via actions)",
      "Box",
    ],
    antiPatterns: [
      "❌ Don't skip — every page that loads data MUST have an empty state",
      "❌ Don't use `icon` / `title` / `description` / single `action` — API is `heading`, `body`, `imageSrc` / `imageSlot`, `actions`",
      "❌ Don't ship without a visual — pass `imageSrc` or `imageSlot` (prefer platform `StitchAsset` in `imageSlot` when a motif exists)",
      "❌ Don't replace the page Header — branch empty BELOW Header",
      "❌ `actions` must be exactly two buttons: `[outline, primary]`",
    ],
    realWorldExamples: [
      {
        title: "No data with illustration + two actions",
        code: `<EmptyState\n  heading="No projects yet"\n  body="Create your first project to get started."\n  imageSrc="/images/empty-table.png"\n  actions={[\n    { children: "Learn more", variant: "outline", onClick: onLearn },\n    { children: "Create project", variant: "primary", onClick: onCreate },\n  ]}\n/>`,
      },
      {
        title: "Empty state with platform StitchAsset",
        code: `import StitchAsset from "@/shared/stitch/components/StitchAsset";\nimport { simulateEmpty } from "@/shared/stitch/lib/motifs";\n\n<EmptyState\n  heading="Create your first test suite"\n  body="Rehearse agent conversations before you go live."\n  imageSlot={\n    <StitchAsset\n      config={simulateEmpty}\n      width={102}\n      height={84}\n      physics\n      resolutionScale={4}\n    />\n  }\n  actions={[\n    { children: "Learn more", variant: "outline", onClick: onLearn },\n    { children: "Create suite", variant: "primary", onClick: onCreate },\n  ]}\n/>`,
      },
    ],
  },

  Avatar: {
    importPath: `import { Avatar } from "@sarvam/tatva";`,
    relatedComponents: [
      "AvatarGroup (stacked users with overflow)",
      "Box + Text (user list rows)",
      "Select / OptionItem (avatar in options)",
    ],
    antiPatterns: [
      "❌ Don't use raw `<img>` for user photos — always `Avatar`",
      "❌ Don't set custom size via CSS — use `size` (`sm` 20 / `md` 28 / `lg` 36)",
      "❌ Don't use `AvatarGroup` for a single avatar — use `Avatar` directly",
      "❌ For platform `StitchAsset` use `imageSlot` (prefer `size=\"lg\"` = 36px for 6×6 motifs) — not `src`",
      "❌ Always pass `fallback` when using `src`",
    ],
    realWorldExamples: [
      {
        title: "User row with image + fallback",
        code: `<Box display="flex" align="center" gap={4}>\n  <Avatar src={user.avatar} alt={user.name} fallback={user.initials} size="md" />\n  <Box display="flex" direction="column">\n    <Text variant="body-md">{user.name}</Text>\n    <Text variant="body-sm" tone="secondary">{user.email}</Text>\n  </Box>\n</Box>`,
      },
      {
        title: "Agent mark with platform StitchAsset",
        code: `import StitchAsset from "@/shared/stitch/components/StitchAsset";\nimport { agentAvatar } from "@/shared/stitch/lib/motifs";\n\n<Avatar\n  size="lg"\n  alt="Billing Agent"\n  fallback="BA"\n  imageSlot={\n    <StitchAsset\n      config={agentAvatar}\n      width={36}\n      height={36}\n      animate={false}\n      physics\n      resolutionScale={4}\n    />\n  }\n/>`,
      },
      {
        title: "AvatarGroup item with StitchAsset",
        code: `import StitchAsset from "@/shared/stitch/components/StitchAsset";\n\n<AvatarGroup\n  size="lg"\n  max={4}\n  avatars={[\n    {\n      alt: "Billing Agent",\n      fallback: "BA",\n      imageSlot: (\n        <StitchAsset\n          config={agentAvatar}\n          width={36}\n          height={36}\n          animate={false}\n          physics\n          resolutionScale={4}\n        />\n      ),\n    },\n    { src: user.avatar, alt: user.name, fallback: user.initials },\n  ]}\n/>`,
      },
    ],
  },

  Header: {
    importPath: `import { Header } from "@sarvam/tatva";`,
    relatedComponents: ["Button (via actions)", "Tabs (below header)", "Box"],
    antiPatterns: [
      "❌ Don't add `description` unless explicitly asked by the user",
      "❌ Don't use a `right=` JSX slot — use `actions={[{ label, onClick, icon? }]}`",
      "❌ Don't unmount Header for loading/empty/error — it is page chrome",
    ],
    realWorldExamples: [
      {
        title: "Page header with action",
        code: `<Header\n  type="main"\n  left={{ title: "Users" }}\n  actions={[{ label: "Add User", icon: "plus", onClick: onAdd }]}\n/>`,
      },
    ],
  },

  Sidebar: {
    importPath: `import { Sidebar, SidebarProvider } from "@sarvam/tatva";`,
    relatedComponents: ["SidebarProvider (required wrapper)", "Header", "Box"],
    antiPatterns: [
      "❌ Don't create groups with only 1 item — combine into a single group",
      "❌ Don't forget SidebarProvider wrapper at the layout level",
      "❌ Don't use Tabs for app-level navigation — use Sidebar",
    ],
    realWorldExamples: [
      {
        title: "Dashboard sidebar with groups",
        code: `<SidebarProvider>\n  <Sidebar\n    menuItems={[\n      {\n        title: "Main",\n        items: [\n          { label: "Dashboard", icon: "home", href: "/dashboard" },\n          { label: "Analytics", icon: "chart-bar", href: "/analytics" },\n          { label: "Users", icon: "users", href: "/users" },\n        ],\n      },\n    ]}\n    activePath={pathname}\n    linkComponent={Link}\n    header={{ logo: "/logo.svg" }}\n  />\n</SidebarProvider>`,
      },
    ],
  },

  Box: {
    importPath: `import { Box } from "@sarvam/tatva";`,
    relatedComponents: ["Text (for content inside)", "Button", "all components (Box is the universal container)"],
    antiPatterns: [
      "❌ Don't use raw `<div>` — always Box for layout",
      "❌ Don't use Tailwind spacing classes — use Box props (`p`, `gap`)",
      "❌ Don't use `className` for bg/border/rounded/layout — use Box props",
      "❌ Don't invent fourth spacing tiers — use gap={2} (pair), gap={10} (field), gap={12} (region)",
      "❌ Prefer parent `gap` over child `mt`/`mb`/`my`",
    ],
    realWorldExamples: [
      {
        title: "Page regions (gap={12})",
        code: `<Box display="flex" direction="column" gap={12} p={12}>\n  <Header type="main" left={{ title: "Voice agents" }} />\n  {/* section */}\n</Box>`,
      },
      {
        title: "Form fields (gap={10})",
        code: `<Box display="flex" direction="column" gap={10}>\n  <Input label="Name" />\n  <Select label="Role" options={roles} />\n</Box>`,
      },
      {
        title: "Label + helper pair (gap={2})",
        code: `<Box display="flex" direction="column" gap={2}>\n  <Text variant="label-md">Default language</Text>\n  <Text variant="body-sm" tone="secondary">Used for new sessions</Text>\n</Box>`,
      },
    ],
  },

  Text: {
    importPath: `import { Text } from "@sarvam/tatva";`,
    relatedComponents: ["Box (container)", "Link (wrap for navigation)"],
    antiPatterns: [
      "❌ Don't use raw <p>, <h1>-<h6>, <span> — always Text",
      "❌ Don't use Tailwind text classes — use Text `variant` and `tone` props",
      "❌ Prefer `heading-sm`+ / `label-md` for app UI — reserve `heading-xs` for dense internal chrome",
    ],
    realWorldExamples: [
      {
        title: "Page heading + subtitle",
        code: `<Box display="flex" direction="column" gap={2}>\n  <Text variant="heading-lg">Dashboard</Text>\n  <Text variant="body-md" tone="secondary">Overview of your metrics</Text>\n</Box>`,
      },
      {
        title: "Inline link",
        code: `<Link href="/signup"><Text variant="body-sm" tone="brand">Create an account</Text></Link>`,
      },
    ],
  },
};

/**
 * Enrich a component docs response with metadata.
 * Returns additional markdown to append to the docs.
 */
export function getEnrichment(componentName) {
  const meta = COMPONENT_METADATA[componentName];
  if (!meta) return null;

  let md = "\n\n---\n\n## 🔧 Usage Guide\n\n";
  md += `### Import\n\n\`\`\`tsx\n${meta.importPath}\n\`\`\`\n\n`;

  if (meta.relatedComponents.length > 0) {
    md += "### Related Components\n\n";
    md += meta.relatedComponents.map((r) => `- ${r}`).join("\n") + "\n\n";
  }

  if (meta.antiPatterns.length > 0) {
    md += "### Anti-Patterns (Don't Do This)\n\n";
    md += meta.antiPatterns.join("\n") + "\n\n";
  }

  if (meta.realWorldExamples.length > 0) {
    md += "### Real-World Examples\n\n";
    for (const ex of meta.realWorldExamples) {
      md += `**${ex.title}:**\n\n\`\`\`tsx\n${ex.code}\n\`\`\`\n\n`;
    }
  }

  return md;
}
