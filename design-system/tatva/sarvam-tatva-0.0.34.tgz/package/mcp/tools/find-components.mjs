/**
 * find_components_for_task tool
 *
 * Task-oriented component discovery. The agent describes what it's building
 * and this tool returns the recommended component set, composition guidance,
 * anti-patterns to avoid, and a suggested pattern to start from.
 */

import * as v from "valibot";

// ─── Component Knowledge Base ────────────────────────────────────────────────

const COMPONENT_DB = {
  // Layout
  Box: {
    category: "layout",
    purpose: "Flex/grid container with Tatva tokens",
    pairsWith: ["Text", "Button"],
    antiPatterns: [
      "Don't use className for spacing — use Box props instead",
      "Prefer parent gap over child margin (mt/mb)",
      "Use spacing tiers: gap={2} pair · gap={10} field · gap={12} region — don't invent fourth tiers",
    ],
  },
  Header: {
    category: "layout",
    purpose: "Page header with title and actions — always stays mounted across loading/empty/error",
    pairsWith: ["Button", "Tabs", "Box"],
    antiPatterns: [
      "Don't add description unless user explicitly asks",
      "Don't replace Header with state components — branch BELOW Header",
      "Use actions={[{ label, onClick }]} — not a right= JSX slot",
    ],
  },
  Sidebar: {
    category: "layout",
    purpose: "Navigation sidebar with grouped menu items",
    pairsWith: ["SidebarProvider", "Header", "Box"],
    antiPatterns: ["Never create groups with only 1 item each"],
  },
  Tabs: {
    category: "layout",
    purpose: "Switch between peer content sections",
    pairsWith: ["Header", "Box"],
    antiPatterns: [
      "Don't use for navigation between pages — use Sidebar",
      "Don't nest tabs",
      "Don't put counts in tab labels",
    ],
  },
  Accordion: {
    category: "layout",
    purpose: "Collapsible content sections",
    pairsWith: ["Box", "Text"],
    antiPatterns: ["Don't nest accordions"],
  },
  Divider: {
    category: "layout",
    purpose: "Visual separator between sections (discouraged by default)",
    pairsWith: ["Box"],
    antiPatterns: [
      "Don't add Divider by default — prefer gap={12} between regions",
      "Only use when the user explicitly asks for a divider",
    ],
  },

  // Data Display
  Table: {
    category: "data-display",
    purpose: "Tabular data with sort/filter/pagination",
    pairsWith: ["Input", "EmptyState", "Skeleton", "Badge"],
    antiPatterns: [
      "Don't use for < 3 rows — use OptionGroup instead",
      "Keep Table mounted — update data/isLoading/isRefetching in place; never remount via unstable key or conditional unmount (stagger replays under AnimationProvider)",
      "Always pass stable getRowId",
      "Set column width with TableColumn.size only — do not use style.width on cell content (distorts header vs body)",
      "Text columns truncate + tooltip-on-overflow by default (truncate: true); set truncate: false to opt out; rich custom cells should use Text lineClamp={1} themselves",
    ],
  },
  MetricCard: {
    category: "data-display",
    purpose: "KPI/stat with optional chart",
    pairsWith: ["BarChart", "LineChart", "Sparkline", "Box"],
    antiPatterns: ["Never put a chart without MetricCard wrapper", "Don't use Card for KPIs"],
  },
  Card: {
    category: "data-display",
    purpose: "Clickable content card with image/CTA",
    pairsWith: ["Avatar", "Badge", "Button"],
    antiPatterns: [
      "Don't use for KPIs — use MetricCard",
      "For stitch pictograms pass StitchAsset as image (ReactNode), not src",
    ],
  },
  EntityCard: {
    category: "data-display",
    purpose: "Semantic media/action/content entity card",
    pairsWith: ["Badge", "Button", "Box"],
    antiPatterns: [
      "Don't use for KPIs — use MetricCard",
      "For StitchAsset use mediaSlot/assetSlot — not mediaSrc/assetSrc URLs",
    ],
  },
  EmptyState: {
    category: "data-display",
    purpose: "Zero-data panel with required illustration",
    pairsWith: ["Button", "Box", "Header"],
    antiPatterns: [
      "Don't skip — every data page needs one",
      "Always pass imageSrc or imageSlot (not icon) — prefer StitchAsset in imageSlot when a motif exists",
      "Requires heading + exactly two actions [outline, primary]",
      "Don't replace the page Header — EmptyState lives below it",
    ],
  },

  // Forms
  Input: {
    category: "forms",
    purpose: "Text input with label, error, icon",
    pairsWith: ["Controller", "Button", "Box"],
    antiPatterns: ["Don't use uncontrolled inputs — always use react-hook-form"],
  },
  Select: {
    category: "forms",
    purpose: "Dropdown selection",
    pairsWith: ["Controller", "Box"],
    antiPatterns: ["Don't build custom dropdowns", "Prefer options with an icon"],
  },
  Textarea: {
    category: "forms",
    purpose: "Multi-line text input",
    pairsWith: ["Controller", "Box"],
    antiPatterns: [],
  },
  TagInput: {
    category: "forms",
    purpose: "Multi-value tag entry",
    pairsWith: ["Controller", "Box"],
    antiPatterns: [],
  },
  Switch: {
    category: "forms",
    purpose: "Boolean toggle for settings",
    pairsWith: ["OptionItem", "Controller"],
    antiPatterns: ["Don't use for form consent — use Checkbox"],
  },
  Checkbox: {
    category: "forms",
    purpose: "Agreement/consent or multi-select",
    pairsWith: ["Controller", "Text"],
    antiPatterns: ["Don't use for settings toggles — use Switch"],
  },
  Radio: {
    category: "forms",
    purpose: "Single choice from small set",
    pairsWith: ["RadioGroup", "Controller"],
    antiPatterns: ["Don't use for > 5 options — use Select"],
  },
  Slider: {
    category: "forms",
    purpose: "Numeric range selection",
    pairsWith: ["Box", "Text"],
    antiPatterns: [],
  },
  DatePicker: {
    category: "forms",
    purpose: "Single date or date range; optional time via showTimeFilter",
    pairsWith: ["Controller", "Box", "TimePicker"],
    antiPatterns: ["Don't use for time-only — use TimePicker"],
  },
  DateRangePicker: {
    category: "forms",
    purpose: "Date range selection (alias of DatePicker mode=range)",
    pairsWith: ["Controller", "Box", "TimePicker"],
    antiPatterns: ["Don't use for time-only — use TimePicker"],
  },
  TimePicker: {
    category: "forms",
    purpose: "Time-only selection with 12h hour/minute/AM·PM columns",
    pairsWith: ["Controller", "Box", "DatePicker", "Icon"],
    antiPatterns: [
      "Don't use for date+time — use DatePicker with showTimeFilter",
      "Don't pass 12h strings as value — use HH:mm 24h",
      "Don't build custom time dropdowns or native input type=time",
    ],
  },
  FileUpload: {
    category: "forms",
    purpose: "File upload with drag & drop",
    pairsWith: ["Box", "Button"],
    antiPatterns: [],
  },

  // Overlays
  Dialog: {
    category: "overlays",
    purpose: "Quick confirmation or short form (1-5 fields)",
    pairsWith: ["Button", "Input", "Text"],
    antiPatterns: ["Don't use for long forms — use Sheet", "Don't nest dialogs"],
  },
  Sheet: {
    category: "overlays",
    purpose: "Slide-over panel for detail views or long forms",
    pairsWith: ["Input", "Select", "Button", "Box"],
    antiPatterns: ["Don't use for simple confirmations — use Dialog"],
  },
  Menu: {
    category: "overlays",
    purpose: "Context menu / dropdown actions",
    pairsWith: ["Button", "Icon"],
    antiPatterns: ["Don't use for navigation — use Sidebar or Tabs"],
  },
  Tooltip: {
    category: "overlays",
    purpose: "Hover hint for icon-only buttons or truncated text",
    pairsWith: ["Button", "Icon", "Text"],
    antiPatterns: ["Don't put interactive content in tooltips"],
  },
  Popover: {
    category: "overlays",
    purpose: "Rich interactive overlay triggered by click",
    pairsWith: ["Button", "Box"],
    antiPatterns: ["Don't use for simple tooltips"],
  },

  // Feedback
  Alert: {
    category: "feedback",
    purpose: "Inline error/warning/success message",
    pairsWith: ["Box", "Button"],
    antiPatterns: ["Don't use for transient notifications — use toast"],
  },
  Skeleton: {
    category: "feedback",
    purpose: "Loading placeholder",
    pairsWith: ["Box", "Header"],
    antiPatterns: ["Don't skip — every async page needs a loading state", "Keep Header mounted while showing Skeleton"],
  },
  Loader: {
    category: "feedback",
    purpose: "Spinner for inline loading",
    pairsWith: ["Box", "Button"],
    antiPatterns: ["Prefer Skeleton for page loads — Loader for inline actions"],
  },
  Stepper: {
    category: "feedback",
    purpose: "Multi-step progress indicator",
    pairsWith: ["Box", "Button"],
    antiPatterns: [],
  },

  // Status
  Badge: {
    category: "status",
    purpose: "Status label, filter chip, or removable tag (there is no Pill)",
    pairsWith: ["Avatar", "Card", "Table", "Box"],
    antiPatterns: ["Don't invent a Pill component — use Badge"],
  },

  // Charts
  BarChart: {
    category: "charts",
    purpose: "Comparison across categories",
    pairsWith: ["MetricCard"],
    antiPatterns: ["Always wrap in MetricCard"],
  },
  LineChart: {
    category: "charts",
    purpose: "Trend over time",
    pairsWith: ["MetricCard"],
    antiPatterns: ["Always wrap in MetricCard"],
  },
  AreaChart: {
    category: "charts",
    purpose: "Volume trend (filled line)",
    pairsWith: ["MetricCard"],
    antiPatterns: ["Always wrap in MetricCard"],
  },
  PieChart: {
    category: "charts",
    purpose: "Part-of-whole distribution",
    pairsWith: ["MetricCard"],
    antiPatterns: ["Always wrap in MetricCard"],
  },
  DonutChart: {
    category: "charts",
    purpose: "Part-of-whole with center stat",
    pairsWith: ["MetricCard"],
    antiPatterns: ["Always wrap in MetricCard"],
  },
  Sparkline: {
    category: "charts",
    purpose: "Minimal inline trend",
    pairsWith: ["MetricCard", "Table"],
    antiPatterns: ["Always wrap in MetricCard if standalone"],
  },
  FunnelChart: {
    category: "charts",
    purpose: "Conversion funnel stages",
    pairsWith: ["MetricCard"],
    antiPatterns: ["Always wrap in MetricCard"],
  },

  // Media
  Avatar: {
    category: "media",
    purpose: "User/entity image (always use even for square images)",
    pairsWith: ["AvatarGroup", "Card", "OptionItem"],
    antiPatterns: [
      "Don't use raw <img> for user photos",
      "For StitchAsset use imageSlot (prefer size=\"lg\" = 36px for 6×6 motifs) — not src",
    ],
  },
  Icon: {
    category: "media",
    purpose: "Built-in icon by name",
    pairsWith: ["Button", "Input", "Box"],
    antiPatterns: ["Don't guess icon names — call list_icons first"],
  },
  WaveformPlayer: {
    category: "media",
    purpose: "Audio waveform playback",
    pairsWith: ["Box"],
    antiPatterns: [],
  },

  // Navigation
  OptionItem: {
    category: "navigation",
    purpose: "Settings row or navigation item with trailing action",
    pairsWith: ["OptionGroup", "Switch", "Select", "Avatar"],
    antiPatterns: [],
  },
  OptionGroup: {
    category: "navigation",
    purpose: "Group of option items with a title",
    pairsWith: ["OptionItem", "Box"],
    antiPatterns: ["Don't separate OptionGroups with Divider — use gap={12}"],
  },

  // Typography
  Text: {
    category: "typography",
    purpose: "All text rendering with semantic variants",
    pairsWith: ["Box", "Link"],
    antiPatterns: [
      "Don't use raw <p>, <h1>-<h6>, <span>",
      "Prefer heading-sm+ for app section titles — heading-xs is for dense internal chrome only",
    ],
  },
  Button: {
    category: "actions",
    purpose: "Primary action trigger",
    pairsWith: ["Dialog", "Box", "Icon"],
    antiPatterns: [
      "Only one primary variant per page section",
      "Don't use className for margins — wrap in Box / use parent gap",
    ],
  },
};

// ─── Task → Component Mapping ────────────────────────────────────────────────

const TASK_KEYWORDS = {
  dashboard: {
    components: ["Header", "MetricCard", "BarChart", "LineChart", "Sparkline", "Box", "Tabs"],
    pattern: "dashboard-analytics",
  },
  analytics: {
    components: ["Header", "MetricCard", "BarChart", "LineChart", "AreaChart", "DonutChart", "Tabs", "Box"],
    pattern: "dashboard-analytics",
  },
  chart: {
    components: ["MetricCard", "BarChart", "LineChart", "AreaChart", "PieChart", "DonutChart"],
    pattern: "dashboard-analytics",
  },
  form: {
    components: ["Input", "Select", "Switch", "Checkbox", "Radio", "Button", "Box", "TimePicker", "DatePicker"],
    pattern: "form-with-validation",
  },
  date: {
    components: ["DatePicker", "DateRangePicker", "Box", "Controller"],
    pattern: null,
  },
  calendar: {
    components: ["DatePicker", "DateRangePicker", "Box"],
    pattern: null,
  },
  time: {
    components: ["TimePicker", "Box", "Icon", "Controller"],
    pattern: "time-availability-range",
  },
  hours: {
    components: ["TimePicker", "Box", "Icon", "Controller"],
    pattern: "time-availability-range",
  },
  availability: {
    components: ["TimePicker", "Box", "Icon", "Button", "Stepper"],
    pattern: "time-availability-range",
  },
  schedule: {
    components: ["TimePicker", "DatePicker", "Box", "Icon"],
    pattern: "time-availability-range",
  },
  login: {
    components: ["Input", "Button", "Checkbox", "Box", "Text"],
    pattern: "login-page",
  },
  signup: {
    components: ["Input", "Button", "Checkbox", "Box", "Text"],
    pattern: "login-page",
  },
  auth: {
    components: ["Input", "Button", "Checkbox", "Box", "Text"],
    pattern: "login-page",
  },
  table: {
    components: ["Table", "Input", "EmptyState", "Header", "Button", "Badge", "Skeleton"],
    pattern: "data-table-with-filters",
  },
  list: {
    components: ["Table", "EmptyState", "Header", "Button", "Box", "Skeleton"],
    pattern: "data-table-with-filters",
  },
  settings: {
    components: ["OptionGroup", "OptionItem", "Switch", "Select", "Header", "Button", "Box"],
    pattern: "settings-page",
  },
  sidebar: {
    components: ["SidebarProvider", "Sidebar", "Header", "Box"],
    pattern: "sidebar-layout",
  },
  layout: {
    components: ["SidebarProvider", "Sidebar", "Header", "Box"],
    pattern: "sidebar-layout",
  },
  dialog: {
    components: ["Dialog", "Button", "Input", "Box"],
    pattern: "dialog-confirmation",
  },
  modal: {
    components: ["Dialog", "Button", "Input", "Box"],
    pattern: "dialog-confirmation",
  },
  sheet: {
    components: ["Sheet", "Input", "Select", "Button", "Box"],
    pattern: "sheet-detail-view",
  },
  detail: {
    components: ["Sheet", "Input", "Select", "Button", "Box", "Text"],
    pattern: "sheet-detail-view",
  },
  chat: {
    components: [
      "Conversation",
      "ConversationContent",
      "Message",
      "MessageContent",
      "PromptInput",
      "PromptInputBody",
      "PromptInputTextarea",
      "PromptInputSubmit",
    ],
    pattern: "chat-interface",
  },
  ai: {
    components: ["Conversation", "Message", "PromptInput", "ChainOfThought", "Reasoning", "Sources"],
    pattern: "chat-interface",
  },
  tabs: {
    components: ["Tabs", "Header", "Box"],
    pattern: "tabs-with-content",
  },
  upload: {
    components: ["FileUpload", "Button", "Box"],
    pattern: null,
  },
  empty: {
    components: ["EmptyState", "Header", "Button", "Box"],
    pattern: "empty-loading-error-states",
  },
  loading: {
    components: ["Skeleton", "Header", "Box"],
    pattern: "empty-loading-error-states",
  },
  error: {
    components: ["Alert", "Header", "Button", "Box"],
    pattern: "empty-loading-error-states",
  },
  notification: {
    components: ["toast", "Toaster"],
    pattern: null,
  },
  stepper: {
    components: ["Stepper", "Button", "Box"],
    pattern: null,
  },
  wizard: {
    components: ["Stepper", "Button", "Box", "Input", "Select"],
    pattern: null,
  },
};

// Prefer list/table archetype when both settings + list keywords match
function pickPattern(matchedKeywords, taskLower) {
  const hasList =
    taskLower.includes("list") ||
    taskLower.includes("table") ||
    taskLower.includes("api key") ||
    taskLower.includes("keys");
  const hasSettings = taskLower.includes("settings");
  if (hasList && hasSettings) {
    return "data-table-with-filters";
  }
  return matchedKeywords.find((m) => m.pattern)?.pattern ?? null;
}

// ─── Tool Definition ─────────────────────────────────────────────────────────

export const definition = {
  name: "find_components_for_task",
  description:
    "Describe what you're building and get back the recommended Tatva component set, " +
    "composition guidance, anti-patterns to avoid, and a suggested pattern to start from. " +
    "Use this BEFORE get_component_docs to know which components to look up.\n\n" +
    "Example: { \"task\": \"settings page with dark mode toggle and language selector\" }",
  schema: v.object({
    task: v.pipe(
      v.string(),
      v.description(
        "Natural language description of what you're building, e.g. " +
          '"dashboard with revenue chart and user stats" or "login page with email and password"'
      )
    ),
    projectPath: v.pipe(
      v.string(),
      v.description(
        "Absolute path to the project root, e.g. /Users/you/my-app. Used for analytics."
      )
    ),
  }),
};

export async function execute({ task }) {
  const taskLower = task.toLowerCase();

  const matchedKeywords = Object.entries(TASK_KEYWORDS)
    .filter(([keyword]) => taskLower.includes(keyword))
    .map(([, config]) => config);

  let componentSet = [...new Set(matchedKeywords.flatMap((m) => m.components))];

  // Settings + list hybrid: drop settings-only controls unless the task is clearly settings
  if (
    (taskLower.includes("list") || taskLower.includes("table") || taskLower.includes("key")) &&
    taskLower.includes("settings")
  ) {
    componentSet = componentSet.filter((c) => !["Switch", "Divider"].includes(c));
  }

  const suggestedPattern = pickPattern(matchedKeywords, taskLower);

  if (componentSet.length === 0) {
    return {
      content: [
        {
          type: "text",
          text:
            `## Component Recommendation for: "${task}"\n\n` +
            "I couldn't match specific components to this task. Here's what to do:\n\n" +
            "1. Call `list_components` to see all available components\n" +
            "2. Call `get_component_docs` for the ones that seem relevant\n" +
            "3. Call `get_patterns` with `[]` to see available composition patterns\n\n" +
            "**General guidelines:**\n" +
            "- Ask the user about primary job, empty/error states, and edge cases before coding\n" +
            "- Every page needs a `Header` (title only, no description) that stays mounted across states\n" +
            "- Use `Box` for all layout (never raw `<div>`); spacing tiers: gap={2}/{10}/{12}\n" +
            "- Data pages must handle: loading (Skeleton), error (Alert), empty (EmptyState + imageSrc), content\n" +
            "- Dashboard pages must use `SidebarProvider` + `Sidebar` layout\n" +
            "- Do not add `Divider` by default",
        },
      ],
    };
  }

  const componentDetails = componentSet
    .map((name) => {
      const info = COMPONENT_DB[name];
      if (!info) return `- **${name}**`;
      const anti =
        info.antiPatterns.length > 0
          ? `\n    ⚠️ ${info.antiPatterns.join("\n    ⚠️ ")}`
          : "";
      return `- **${name}** — ${info.purpose}${anti}`;
    })
    .join("\n");

  const pairingNotes = componentSet
    .map((name) => {
      const info = COMPONENT_DB[name];
      if (!info || info.pairsWith.length === 0) return null;
      return `- ${name} → pairs with: ${info.pairsWith.join(", ")}`;
    })
    .filter(Boolean)
    .join("\n");

  let response = `## Component Recommendation for: "${task}"\n\n`;
  response += `### Recommended Components (${componentSet.length})\n\n${componentDetails}\n\n`;
  response += `### Composition Notes\n\n${pairingNotes}\n\n`;
  response += `### Spacing reminder\n\n`;
  response += `- Pair (parts of one thing): \`gap={2}\`\n`;
  response += `- Field (sibling questions): \`gap={10}\`\n`;
  response += `- Region (page sections): \`gap={12}\`\n`;
  response += `- Prefer parent \`gap\` over child \`mt\`/\`mb\`\n\n`;

  if (suggestedPattern) {
    response += `### Suggested Starting Pattern\n\n`;
    response += `Call \`get_patterns\` with \`{ "patterns": ["${suggestedPattern}"] }\` to get a full copy-paste template.\n\n`;
  }

  response += `### Next Steps\n\n`;
  response += `1. Clarify UX/edge cases with the user if anything is ambiguous\n`;
  response += `2. Call \`get_component_docs\` with: ${JSON.stringify(componentSet.slice(0, 8))}\n`;
  response += `3. ${suggestedPattern ? `Get the pattern: \`get_patterns({ patterns: ["${suggestedPattern}"] })\`` : "Check `get_patterns` for available templates"}\n`;
  response += `4. Adapt the pattern — never ship only the happy path\n`;

  return {
    content: [{ type: "text", text: response }],
  };
}
