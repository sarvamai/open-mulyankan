/**
 * list_icons tool
 *
 * Returns every built-in icon name from the Tatva design system.
 * Parses iconComponents keys from lib/icons.ts at startup so the list
 * stays in sync with the source without needing a compiled build.
 */

import { readFile } from "node:fs/promises";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";
import * as v from "valibot";

const __dirname = dirname(fileURLToPath(import.meta.url));
const ICONS_FILE = join(__dirname, "..", "..", "lib", "icons.ts");

let cachedNames = null;

async function getIconNames() {
  if (cachedNames) return cachedNames;

  const source = await readFile(ICONS_FILE, "utf-8");

  // Extract keys from `export const iconComponents = { ... } as const;`
  const match = source.match(/export\s+const\s+iconComponents\s*=\s*\{([\s\S]*?)\}\s*as\s+const/);
  if (!match) return [];

  const body = match[1];
  const names = [];
  for (const line of body.split("\n")) {
    // Matches both quoted keys ("arrow-left":) and bare keys (plus:)
    const keyMatch = line.match(/^\s*"?([a-z][a-z0-9-]*)"?\s*:/);
    if (keyMatch) names.push(keyMatch[1]);
  }

  cachedNames = names;
  return names;
}

export const definition = {
  name: "list_icons",
  description:
    "Returns all available built-in icon names in @sarvam/tatva. " +
    "Call this before using any icon to know which names are valid.",
  schema: v.object({
    projectPath: v.pipe(
      v.string(),
      v.description(
        "Absolute path to the project root, e.g. /Users/you/my-app. " +
        "Used for analytics — always pass this."
      )
    ),
  }),
};

export async function execute() {
  try {
    const names = await getIconNames();

    if (names.length === 0) {
      return {
        content: [{ type: "text", text: "No icons found. Could not parse lib/icons.ts." }],
      };
    }

    return {
      content: [{
        type: "text",
        text: `## Available Icons (${names.length})\n\n${names.map((n) => `- ${n}`).join("\n")}\n\n## How to use icons\n\nUse the \`name\` prop with the exact icon name from the list above:\n\n\`\`\`tsx\nimport { Icon } from "@sarvam/tatva";\n\n<Icon name="search" />\n<Icon name="arrow-left" />\n\`\`\`\n\nButtons and other components accept an \`icon\` prop:\n\n\`\`\`tsx\n<Button icon="download">Export</Button>\n\`\`\`\n\nIMPORTANT: Only use icon names from the list above. Do NOT use HugeIcons component names or any other format.\n\nIf you need to add custom icons via \`IconProvider\`, find it in the project by running:\n\n\`\`\`bash\ngrep -r "IconProvider" --include="*.tsx" --include="*.ts" -l .\n\`\`\`\n\nThen check its \`extend\` prop for extra icon names already registered in the project.`,
      }],
    };
  } catch (err) {
    return {
      isError: true,
      content: [{ type: "text", text: `Error reading icons: ${err.message}` }],
    };
  }
}
