/**
 * Tatva MCP Prompts
 *
 * Reusable prompt templates that appear as slash-commands in Cursor (e.g.
 * /tatva-copywriter). System messages live in co-located .md files so
 * non-technical team members can edit them without touching JavaScript.
 *
 * To add a new prompt:
 *   1. Create a new .md file in this folder with the system message content
 *   2. Add an entry to the PROMPTS array below
 */

import { readFileSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = dirname(fileURLToPath(import.meta.url));
const read = (file) => readFileSync(join(__dirname, file), "utf-8");

// ─── Prompt registry ───────────────────────────────────────────────────────────

const PROMPTS = [
  {
    name: "tatva-copywriter",
    title: "Tatva Copywriter",
    description:
      "Write professional UI copy for a B2B SaaS product. " +
      "Generates concise, clear text for buttons, headings, descriptions, " +
      "empty states, error messages, toasts, labels, and placeholders.",
    systemFile: "copywriter.md",
    arguments: [
      {
        name: "context",
        description:
          "What the UI is for — e.g. 'agent management dashboard', " +
          "'file upload dialog', 'onboarding flow for new users'",
        required: true,
      },
    ],
    userMessage: ({ context }) => `Write UI copy for: ${context}`,
  },

  {
    name: "tatva-figma-to-tatva",
    title: "Figma to Tatva",
    description:
      "Convert a Figma design into production-ready Tatva code. " +
      "Fetches the design via Figma MCP, maps layout/colors/typography " +
      "to Tatva components and tokens, and outputs clean React/TSX.",
    systemFile: "figma-to-tatva.md",
    arguments: [
      {
        name: "figmaUrl",
        description:
          "Figma link to the frame or page to convert — " +
          "e.g. 'https://www.figma.com/design/abc123/MyProject?node-id=1-234'",
        required: true,
      },
    ],
    userMessage: ({ figmaUrl }) =>
      `Convert this Figma design to Tatva code: ${figmaUrl}`,
  },

  {
    name: "tatva-refactor-to-tatva",
    title: "Refactor to Tatva",
    description:
      "Migrate existing React code (raw HTML, Tailwind, custom components) " +
      "to use Tatva design system components and tokens. Preserves all " +
      "business logic — only changes the presentation layer.",
    systemFile: "refactor-to-tatva.md",
    arguments: [
      {
        name: "description",
        description:
          "Optional focus area — e.g. 'convert the settings page', " +
          "'migrate all form inputs', 'replace the custom sidebar'",
        required: false,
      },
    ],
    userMessage: ({ description }) => {
      const focus = description ? ` Focus on: ${description}` : "";
      return `Refactor the current code to use Tatva components and tokens.${focus}`;
    },
  },
];

// Pre-load all .md files at startup
for (const prompt of PROMPTS) {
  prompt._system = read(prompt.systemFile);
}

// ─── Helpers for server.mjs ────────────────────────────────────────────────────

/** Build the response for prompts/list */
export function listPrompts() {
  return {
    prompts: PROMPTS.map(({ name, title, description, arguments: args }) => ({
      name,
      title,
      description,
      arguments: args,
    })),
  };
}

/** Build the response for prompts/get */
export function getPrompt(name, args = {}) {
  const prompt = PROMPTS.find((p) => p.name === name);
  if (!prompt) {
    return { _error: true, code: -32602, message: `Unknown prompt: "${name}"` };
  }
  return {
    description: prompt.description,
    messages: [
      {
        role: "user",
        content: {
          type: "text",
          text: `${prompt._system}\n\n---\n\n${prompt.userMessage(args)}`,
        },
      },
    ],
  };
}
