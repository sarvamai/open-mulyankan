/** @type {import('tailwindcss').Config} */
module.exports = {
  theme: {
    extend: {
      fontFamily: {
        matter: ["var(--tatva-family-matter)"],
        season: ["var(--tatva-family-season)"],
        mono: ["var(--tatva-family-mono)"],
      },
      colors: {
        transparent: "transparent",
        current: "currentColor",
        tatva: {
          // Background colors
          background: {
            default: "rgb(var(--tatva-background-primary))",
            primary: {
              DEFAULT: "rgb(var(--tatva-background-primary))",
              hover: "rgb(var(--tatva-background-primary-hover))",
            },
            secondary: {
              DEFAULT: "rgb(var(--tatva-background-secondary))",
              hover: "rgb(var(--tatva-background-secondary-hover))",
            },
            tertiary: {
              DEFAULT: "rgb(var(--tatva-background-tertiary))",
              hover: "rgb(var(--tatva-background-tertiary-hover))",
            },
            black: {
              DEFAULT: "rgb(var(--tatva-background-black) / <alpha-value>)",
              hover: "rgb(var(--tatva-background-black-hover) / <alpha-value>)",
            },
          },

          // Content colors
          content: {
            DEFAULT: "rgb(var(--tatva-content-primary))",
            primary: "rgb(var(--tatva-content-primary))",
            inverse: "rgb(var(--tatva-content-inverse))",
            secondary: "rgb(var(--tatva-content-secondary))",
            tertiary: "rgb(var(--tatva-content-tertiary))",
            quaternary: "rgb(var(--tatva-content-quaternary))",
          },

          // Surface colors
          surface: {
            DEFAULT: "rgb(var(--tatva-surface-primary))",
            primary: "rgb(var(--tatva-surface-primary))",
            secondary: "rgb(var(--tatva-surface-secondary))",
          },

          // Border colors
          border: {
            DEFAULT: "rgb(var(--tatva-border-primary))",
            primary: "rgb(var(--tatva-border-primary))",
            secondary: "rgb(var(--tatva-border-secondary))",
            tertiary: "rgb(var(--tatva-border-tertiary))",
          },

          // Divider colors
          divider: {
            DEFAULT: "rgb(var(--tatva-divider-primary))",
            primary: "rgb(var(--tatva-divider-primary))",
            secondary: "rgb(var(--tatva-divider-secondary))",
          },

          // Brand colors
          brand: {
            DEFAULT: "rgb(var(--tatva-brand-primary))",
            primary: {
              DEFAULT: "rgb(var(--tatva-brand-primary))",
              hover: "rgb(var(--tatva-brand-primary-hover))",
            },
            secondary: {
              DEFAULT: "rgb(var(--tatva-brand-secondary))",
              hover: "rgb(var(--tatva-brand-secondary-hover))",
            },
            content: {
              primary: "rgb(var(--tatva-brand-content-primary))",
              secondary: "rgb(var(--tatva-brand-content-secondary))",
            },
            foreground: "rgb(var(--tatva-brand-foreground))",
          },

          // Semantic colors - Positive
          positive: {
            DEFAULT: "rgb(var(--tatva-positive-content))",
            background: "rgb(var(--tatva-positive-background))",
            content: "rgb(var(--tatva-positive-content))",
          },

          // Semantic colors - Warning
          warning: {
            DEFAULT: "rgb(var(--tatva-warning-content))",
            background: "rgb(var(--tatva-warning-background))",
            content: "rgb(var(--tatva-warning-content))",
          },

          // Semantic colors - Danger
          danger: {
            DEFAULT: "rgb(var(--tatva-danger-content))",
            background: {
              DEFAULT: "rgb(var(--tatva-danger-background))",
              hover: "rgb(var(--tatva-danger-background-hover))",
            },
            content: "rgb(var(--tatva-danger-content))",
          },

          // Accent colors - Indigo
          indigo: {
            DEFAULT: "rgb(var(--tatva-indigo-content))",
            50: "rgb(var(--tatva-indigo-50))",
            100: "rgb(var(--tatva-indigo-100))",
            200: "rgb(var(--tatva-indigo-200))",
            300: "rgb(var(--tatva-indigo-300))",
            400: "rgb(var(--tatva-indigo-400))",
            500: "rgb(var(--tatva-indigo-500))",
            600: "rgb(var(--tatva-indigo-600))",
            700: "rgb(var(--tatva-indigo-700))",
            800: "rgb(var(--tatva-indigo-800))",
            900: "rgb(var(--tatva-indigo-900))",
            background: "rgb(var(--tatva-indigo-background))",
            content: "rgb(var(--tatva-indigo-content))",
          },

          // Accent colors - Orange
          orange: {
            DEFAULT: "rgb(var(--tatva-orange-content))",
            50: "rgb(var(--tatva-orange-50))",
            100: "rgb(var(--tatva-orange-100))",
            200: "rgb(var(--tatva-orange-200))",
            300: "rgb(var(--tatva-orange-300))",
            400: "rgb(var(--tatva-orange-400))",
            500: "rgb(var(--tatva-orange-500))",
            600: "rgb(var(--tatva-orange-600))",
            700: "rgb(var(--tatva-orange-700))",
            800: "rgb(var(--tatva-orange-800))",
            900: "rgb(var(--tatva-orange-900))",
            background: "rgb(var(--tatva-orange-background))",
            content: "rgb(var(--tatva-orange-content))",
          },

          // Accent colors - Green
          green: {
            DEFAULT: "rgb(var(--tatva-green-content))",
            50: "rgb(var(--tatva-green-50))",
            100: "rgb(var(--tatva-green-100))",
            200: "rgb(var(--tatva-green-200))",
            300: "rgb(var(--tatva-green-300))",
            400: "rgb(var(--tatva-green-400))",
            500: "rgb(var(--tatva-green-500))",
            600: "rgb(var(--tatva-green-600))",
            700: "rgb(var(--tatva-green-700))",
            800: "rgb(var(--tatva-green-800))",
            900: "rgb(var(--tatva-green-900))",
            background: "rgb(var(--tatva-green-background))",
            content: "rgb(var(--tatva-green-content))",
          },

          // Accent colors - Pink
          pink: {
            DEFAULT: "rgb(var(--tatva-pink-content))",
            50: "rgb(var(--tatva-pink-50))",
            100: "rgb(var(--tatva-pink-100))",
            200: "rgb(var(--tatva-pink-200))",
            300: "rgb(var(--tatva-pink-300))",
            400: "rgb(var(--tatva-pink-400))",
            500: "rgb(var(--tatva-pink-500))",
            600: "rgb(var(--tatva-pink-600))",
            700: "rgb(var(--tatva-pink-700))",
            800: "rgb(var(--tatva-pink-800))",
            900: "rgb(var(--tatva-pink-900))",
            background: "rgb(var(--tatva-pink-background))",
            content: "rgb(var(--tatva-pink-content))",
          },

          // Accent colors - Red
          red: {
            DEFAULT: "rgb(var(--tatva-red-content))",
            50: "rgb(var(--tatva-red-50))",
            100: "rgb(var(--tatva-red-100))",
            200: "rgb(var(--tatva-red-200))",
            300: "rgb(var(--tatva-red-300))",
            400: "rgb(var(--tatva-red-400))",
            500: "rgb(var(--tatva-red-500))",
            600: "rgb(var(--tatva-red-600))",
            700: "rgb(var(--tatva-red-700))",
            800: "rgb(var(--tatva-red-800))",
            900: "rgb(var(--tatva-red-900))",
            background: "rgb(var(--tatva-red-background))",
            content: "rgb(var(--tatva-red-content))",
          },

          // Accent colors - Yellow
          yellow: {
            DEFAULT: "rgb(var(--tatva-yellow-content))",
            50: "rgb(var(--tatva-yellow-50))",
            100: "rgb(var(--tatva-yellow-100))",
            200: "rgb(var(--tatva-yellow-200))",
            300: "rgb(var(--tatva-yellow-300))",
            400: "rgb(var(--tatva-yellow-400))",
            500: "rgb(var(--tatva-yellow-500))",
            600: "rgb(var(--tatva-yellow-600))",
            700: "rgb(var(--tatva-yellow-700))",
            800: "rgb(var(--tatva-yellow-800))",
            900: "rgb(var(--tatva-yellow-900))",
            background: "rgb(var(--tatva-yellow-background))",
            content: "rgb(var(--tatva-yellow-content))",
          },
        },
      },
      borderRadius: {
        "tatva-none": "0px",
        "tatva-xs": "calc(var(--tatva-radius-base) * 1)", // 4px
        "tatva-sm": "calc(var(--tatva-radius-base) * 2)", // 8px
        "tatva-md": "calc(var(--tatva-radius-base) * 3)", // 12px
        "tatva-lg": "calc(var(--tatva-radius-base) * 5)", // 20px
        "tatva-xl": "calc(var(--tatva-radius-base) * 7)", // 28px
        "tatva-full": "calc(var(--tatva-radius-base) * 999)", // big number
      },
      fontSize: {
        "tatva-body-xs": "var(--tatva-font-size-base)",
        "tatva-body-sm": "calc(var(--tatva-font-size-base) + 2px)",
        "tatva-body-md": "calc(var(--tatva-font-size-base) + 3px)",
        "tatva-body-lg": "calc(var(--tatva-font-size-base) + 6px)",
        "tatva-label-md": "calc(var(--tatva-font-size-base) + 3px)",
        "tatva-label-sm": "calc(var(--tatva-font-size-base) + 2px)",
        "tatva-heading-xs": "calc(var(--tatva-font-size-base) + 4px)",
        "tatva-heading-sm": "calc(var(--tatva-font-size-base) + 6px)",
        "tatva-heading-md": "calc(var(--tatva-font-size-base) + 8px)",
        "tatva-heading-lg": "calc(var(--tatva-font-size-base) + 12px)",
        "tatva-heading-xl": "calc(var(--tatva-font-size-base) + 20px)",
        "tatva-code": "calc(var(--tatva-font-size-base) + 2px)",
      },
      boxShadow: {
        "tatva-l1":
          "0 0 var(--tatva-shadow-l1-blur) 0 rgb(var(--tatva-shadow-l1-color) / 0.08)",
        "tatva-l2":
          "0 0 var(--tatva-shadow-l2-blur) 0 rgb(var(--tatva-shadow-l2-color) / 0.16)",
      },
      gridTemplateRows: {
        "tatva-0": "0fr",
        "tatva-1": "1fr",
      },
      translate: {
        0: "0",
        "1/2": "50%",
        "-1/2": "-50%",
        full: "100%",
        "-full": "-100%",
      },
      maxWidth: ({ theme }) => ({
        ...theme("spacing"),
      }),
      spacing: {
        auto: "auto",
        "1/2": "50%",
        full: "100%",
        screen: "100vh",
        px: "1px",
        // Tatva spacing tokens (flat keys for p-tatva-6, gap-tatva-4, etc.)
        "tatva-0": "calc(var(--tatva-spacing-base) * 0)", // 0px
        "tatva-0.5": "calc(var(--tatva-spacing-base) * 0.5)", // 1px
        "tatva-1": "calc(var(--tatva-spacing-base) * 1)", // 2px
        "tatva-2": "calc(var(--tatva-spacing-base) * 2)", // 4px
        "tatva-3": "calc(var(--tatva-spacing-base) * 3)", // 6px
        "tatva-4": "calc(var(--tatva-spacing-base) * 4)", // 8px
        "tatva-5": "calc(var(--tatva-spacing-base) * 5)", // 10px
        "tatva-6": "calc(var(--tatva-spacing-base) * 6)", // 12px
        "tatva-7": "calc(var(--tatva-spacing-base) * 7)", // for icons in button
        "tatva-8": "calc(var(--tatva-spacing-base) * 8)", // 16px
        "tatva-9": "calc(var(--tatva-spacing-base) * 9)", // for icons in button
        "tatva-10": "calc(var(--tatva-spacing-base) * 10)", // 20px
        "tatva-12": "calc(var(--tatva-spacing-base) * 12)", // 24px
        "tatva-14": "calc(var(--tatva-spacing-base) * 14)", // 28px
        "tatva-16": "calc(var(--tatva-spacing-base) * 16)", // 32px
        "tatva-18": "calc(var(--tatva-spacing-base) * 18)", // 36px
        "tatva-20": "calc(var(--tatva-spacing-base) * 20)", // 40px
        "tatva-22": "calc(var(--tatva-spacing-base) * 22)", // 44px
        "tatva-24": "calc(var(--tatva-spacing-base) * 24)", // 48px
        "tatva-26": "calc(var(--tatva-spacing-base) * 26)", // 52px
        "tatva-27": "calc(var(--tatva-spacing-base) * 27)", // 52px
        "tatva-28": "calc(var(--tatva-spacing-base) * 28)", // 56px
        "tatva-30": "calc(var(--tatva-spacing-base) * 30)", // 60px
        "tatva-31": "calc(var(--tatva-spacing-base) * 31)", // 62 (for fileUpload vertical spacing)
        "tatva-32": "calc(var(--tatva-spacing-base) * 32)", // 64px
        "tatva-34": "calc(var(--tatva-spacing-base) * 34)", // 68px
        "tatva-36": "calc(var(--tatva-spacing-base) * 36)", // 72px
        "tatva-38": "calc(var(--tatva-spacing-base) * 38)", // 76px
        "tatva-40": "calc(var(--tatva-spacing-base) * 40)", // 80px
        "tatva-46": "calc(var(--tatva-spacing-base) * 46)", // 92px (for assetContainer)
        "tatva-60": "calc(var(--tatva-spacing-base) * 60)", // for dialog
        "tatva-72": "calc(var(--tatva-spacing-base) * 72)", // for DateRangePicker (time filter width)
        "tatva-80": "calc(var(--tatva-spacing-base) * 80)", // 160px (for assetContainer)
        "tatva-100": "calc(var(--tatva-spacing-base) * 100)", // for filters
        "tatva-120": "calc(var(--tatva-spacing-base) * 120)", // for dialog
        "tatva-124": "calc(var(--tatva-spacing-base) * 124)", // for sidebar (248px)
        "tatva-140": "calc(var(--tatva-spacing-base) * 140)", // for tooltip and toast
        "tatva-150": "calc(var(--tatva-spacing-base) * 150)", // for Loader with text
        // Sheet widths
        "tatva-160": "calc(var(--tatva-spacing-base) * 160)", // 320px - Sheet sm
        "tatva-210": "calc(var(--tatva-spacing-base) * 210)", // 420px - Sheet md
        "tatva-300": "calc(var(--tatva-spacing-base) * 300)", // 600px - Sheet lg
        "tatva-400": "calc(var(--tatva-spacing-base) * 400)", // 800px - Sheet xl
        "tatva-600": "calc(var(--tatva-spacing-base) * 600)", // 1200px - Sheet full max-width
      },
      keyframes: {
        "tatva-spin": {
          from: { transform: "rotate(0deg)" },
          to: { transform: "rotate(360deg)" },
        },
        "tatva-fade-in": {
          from: { opacity: "0" },
          to: { opacity: "1" },
        },
        "tatva-fade-out": {
          from: { opacity: "1" },
          to: { opacity: "0" },
        },
        "tatva-slide-in-from-right": {
          from: { transform: "translateX(100%)" },
          to: { transform: "translateX(0)" },
        },
        "tatva-slide-out-to-right": {
          from: { transform: "translateX(0)" },
          to: { transform: "translateX(100%)" },
        },
        "tatva-slide-in-from-left": {
          from: { transform: "translateX(-100%)" },
          to: { transform: "translateX(0)" },
        },
        "tatva-slide-out-to-left": {
          from: { transform: "translateX(0)" },
          to: { transform: "translateX(-100%)" },
        },
        "tatva-zoom-in": {
          from: { opacity: "0", transform: "scale(0.95)" },
          to: { opacity: "1", transform: "scale(1)" },
        },
        "tatva-zoom-out": {
          from: { opacity: "1", transform: "scale(1)" },
          to: { opacity: "0", transform: "scale(0.95)" },
        },
        "tatva-dialog-overlay-in": {
          from: { opacity: "0" },
          to: { opacity: "1" },
        },
        "tatva-dialog-overlay-out": {
          from: { opacity: "1" },
          to: { opacity: "0" },
        },
        "tatva-dialog-content-in": {
          from: {
            opacity: "0",
            transform: "translate(-50%, -50%) scale(0.96)",
          },
          to: {
            opacity: "1",
            transform: "translate(-50%, -50%) scale(1)",
          },
        },
        "tatva-dialog-content-out": {
          from: {
            opacity: "1",
            transform: "translate(-50%, -50%) scale(1)",
          },
          to: {
            opacity: "0",
            transform: "translate(-50%, -50%) scale(0.96)",
          },
        },
        "tatva-dialog-fullscreen-in": {
          from: { opacity: "0", transform: "scale(0.96)" },
          to: { opacity: "1", transform: "scale(1)" },
        },
        "tatva-dialog-fullscreen-out": {
          from: { opacity: "1", transform: "scale(1)" },
          to: { opacity: "0", transform: "scale(0.96)" },
        },
        "tatva-skeleton-shimmer": {
          "0%": { backgroundPosition: "-1000px 0" },
          "100%": { backgroundPosition: "1000px 0" },
        },
        "tatva-skeleton-pulse": {
          "0%, 100%": { opacity: "1" },
          "50%": { opacity: "0.5" },
        },
        "tatva-accordion-down": {
          from: { height: "0" },
          to: { height: "var(--radix-accordion-content-height)" },
        },
        "tatva-accordion-up": {
          from: { height: "var(--radix-accordion-content-height)" },
          to: { height: "0" },
        },
        "tatva-linear-loader": {
          "0%": { transform: "translateX(-100%)" },
          "100%": { transform: "translateX(400%)" },
        },
        "tatva-bounce-down": {
          "0%, 100%": { transform: "translateY(0)" },
          "50%": { transform: "translateY(3px)" },
        },
        // Micro-interaction keyframes (light up under AnimationProvider)
        "tatva-table-row-in": {
          // opacity-only — a translateY here transiently overflows the table's
          // horizontal scroll wrapper (overflow-x:auto forces overflow-y:auto)
          // and flashes a vertical scrollbar during the stagger.
          from: { opacity: "0" },
          to: { opacity: "1" },
        },
        "tatva-chart-tooltip-in": {
          from: { opacity: "0", transform: "scale(0.97)" },
          to: { opacity: "1", transform: "scale(1)" },
        },
        "tatva-blur-fade-in": {
          from: {
            opacity: "0",
            transform: "translateY(6px)",
            filter: "blur(6px)",
          },
          to: {
            opacity: "1",
            transform: "translateY(0)",
            filter: "blur(0)",
          },
        },
        "tatva-live-ping": {
          "0%": { transform: "scale(1)", opacity: "0.6" },
          "75%, 100%": { transform: "scale(2.5)", opacity: "0" },
        },
        "tatva-shake": {
          "0%, 100%": { transform: "translateX(0)" },
          "25%": { transform: "translateX(-3px)" },
          "75%": { transform: "translateX(3px)" },
        },
        "tatva-wobble": {
          "0%, 100%": { transform: "rotate(0deg) scale(1)" },
          "20%": { transform: "rotate(-9deg) scale(1.12)" },
          "40%": { transform: "rotate(7deg) scale(1.12)" },
          "60%": { transform: "rotate(-5deg) scale(1.1)" },
          "80%": { transform: "rotate(3deg) scale(1.08)" },
        },
        "tatva-badge-pop": {
          "0%": { transform: "scale(1)" },
          "50%": { transform: "scale(1.15)" },
          "100%": { transform: "scale(1)" },
        },
        // Bouncy entrances (overshoot lives in the keyframe, so easing can
        // stay ease-out and the bounce is reliable everywhere).
        "tatva-check-pop": {
          "0%": { transform: "scale(0)" },
          "55%": { transform: "scale(1.2)" },
          "100%": { transform: "scale(1)" },
        },
        "tatva-pop-in": {
          "0%": { opacity: "0", transform: "scale(0.92)" },
          "55%": { opacity: "1", transform: "scale(1.02)" },
          "100%": { transform: "scale(1)" },
        },
        "tatva-dialog-pop-in": {
          "0%": {
            opacity: "0",
            transform: "translate(-50%, -50%) scale(0.94)",
          },
          "55%": {
            opacity: "1",
            transform: "translate(-50%, -50%) scale(1.02)",
          },
          "100%": {
            opacity: "1",
            transform: "translate(-50%, -50%) scale(1)",
          },
        },
      },
      animation: {
        // Infinite loaders keep fixed timings: progress affordances are
        // deliberately exempt from the motion token system / motion-off.
        "tatva-spin": "tatva-spin 1s linear infinite",
        "tatva-skeleton-shimmer": "tatva-skeleton-shimmer 2s infinite linear",
        "tatva-skeleton-pulse": "tatva-skeleton-pulse 2s infinite ease-in-out",
        "tatva-linear-loader": "tatva-linear-loader 1.5s infinite ease-in-out",
        "tatva-bounce-down": "tatva-bounce-down 1.5s ease-in-out infinite",
        "tatva-live-ping":
          "tatva-live-ping 1.6s cubic-bezier(0, 0, 0.2, 1) infinite",
        // Tokenized animations: read AnimationProvider CSS vars. Fallbacks are
        // 0ms so tokenized motion is dormant without a provider (loaders above
        // keep fixed infinite timings and stay exempt).
        "tatva-fade-in":
          "tatva-fade-in var(--tatva-motion-duration-normal, 0ms) var(--tatva-motion-ease-out, ease-out)",
        "tatva-fade-out":
          "tatva-fade-out var(--tatva-motion-duration-normal, 0ms) var(--tatva-motion-ease-in, ease-in)",
        "tatva-slide-in-from-right":
          "tatva-slide-in-from-right var(--tatva-motion-duration-slow, 0ms) var(--tatva-motion-ease-out, ease-out)",
        "tatva-slide-out-to-right":
          "tatva-slide-out-to-right var(--tatva-motion-duration-slow, 0ms) var(--tatva-motion-ease-in, ease-in)",
        "tatva-slide-in-from-left":
          "tatva-slide-in-from-left var(--tatva-motion-duration-slow, 0ms) var(--tatva-motion-ease-out, ease-out)",
        "tatva-slide-out-to-left":
          "tatva-slide-out-to-left var(--tatva-motion-duration-slow, 0ms) var(--tatva-motion-ease-in, ease-in)",
        "tatva-zoom-in":
          "tatva-zoom-in var(--tatva-motion-duration-normal, 0ms) var(--tatva-motion-ease-out, ease-out)",
        "tatva-zoom-out":
          "tatva-zoom-out var(--tatva-motion-duration-normal, 0ms) var(--tatva-motion-ease-in, ease-in)",
        "tatva-dialog-overlay-in":
          "tatva-dialog-overlay-in var(--tatva-motion-duration-fast, 0ms) var(--tatva-motion-ease-out, ease-out) forwards",
        "tatva-dialog-overlay-out":
          "tatva-dialog-overlay-out var(--tatva-motion-duration-fast, 0ms) var(--tatva-motion-ease-in, ease-in) forwards",
        "tatva-dialog-content-in":
          "tatva-dialog-content-in var(--tatva-motion-duration-slow, 0ms) var(--tatva-motion-ease-emphasized, cubic-bezier(0.16, 1, 0.3, 1)) forwards",
        "tatva-dialog-content-out":
          "tatva-dialog-content-out var(--tatva-motion-duration-fast, 0ms) var(--tatva-motion-ease-in, ease-in) forwards",
        "tatva-dialog-fullscreen-in":
          "tatva-dialog-fullscreen-in var(--tatva-motion-duration-normal, 0ms) var(--tatva-motion-ease-emphasized, cubic-bezier(0.16, 1, 0.3, 1)) forwards",
        "tatva-dialog-fullscreen-out":
          "tatva-dialog-fullscreen-out var(--tatva-motion-duration-fast, 0ms) var(--tatva-motion-ease-in, ease-in) forwards",
        "tatva-accordion-down":
          "tatva-accordion-down var(--tatva-motion-duration-normal, 0ms) var(--tatva-motion-ease-out, ease-out)",
        "tatva-accordion-up":
          "tatva-accordion-up var(--tatva-motion-duration-normal, 0ms) var(--tatva-motion-ease-out, ease-out)",
        // Micro-interaction animations (JS-gated classes + 0ms CSS fallbacks)
        "tatva-table-row-in":
          "tatva-table-row-in var(--tatva-motion-duration-slow, 0ms) var(--tatva-motion-ease-out, ease-out) both",
        "tatva-chart-tooltip-in":
          "tatva-chart-tooltip-in var(--tatva-motion-duration-fast, 0ms) var(--tatva-motion-ease-out, ease-out)",
        "tatva-blur-fade-in":
          "tatva-blur-fade-in var(--tatva-motion-duration-reveal, 0ms) var(--tatva-motion-ease-out, ease-out) both",
        "tatva-shake":
          "tatva-shake var(--tatva-motion-duration-normal, 0ms) ease-in-out",
        "tatva-wobble":
          "tatva-wobble var(--tatva-motion-duration-slower, 0ms) ease-in-out",
        "tatva-badge-pop":
          "tatva-badge-pop var(--tatva-motion-duration-normal, 0ms) var(--tatva-motion-ease-out, ease-out)",
        "tatva-check-pop":
          "tatva-check-pop var(--tatva-motion-duration-normal, 0ms) var(--tatva-motion-ease-out, ease-out)",
        "tatva-pop-in":
          "tatva-pop-in var(--tatva-motion-duration-normal, 0ms) var(--tatva-motion-ease-out, ease-out)",
        "tatva-dialog-pop-in":
          "tatva-dialog-pop-in var(--tatva-motion-duration-slow, 0ms) var(--tatva-motion-ease-out, ease-out) forwards",
      },
      transitionDuration: {
        "tatva-instant": "var(--tatva-motion-duration-instant, 0ms)",
        "tatva-fast": "var(--tatva-motion-duration-fast, 0ms)",
        "tatva-normal": "var(--tatva-motion-duration-normal, 0ms)",
        "tatva-slow": "var(--tatva-motion-duration-slow, 0ms)",
      },
      transitionTimingFunction: {
        "tatva-out":
          "var(--tatva-motion-ease-out, cubic-bezier(0.23, 1, 0.32, 1))",
        "tatva-emphasized":
          "var(--tatva-motion-ease-emphasized, cubic-bezier(0.16, 1, 0.3, 1))",
        "tatva-spring":
          "var(--tatva-motion-ease-spring, cubic-bezier(0.34, 1.42, 0.5, 1))",
      },
    },
  },
  plugins: [require("@tailwindcss/container-queries")],
};
