# Tatva

Sarvam's design system. `@sarvam/tatva` ships 40+ React components, a Tailwind preset with semantic design tokens, and auto-configuration for consumer projects. Everything is TypeScript, ESM, and `"use client"`-ready for Next.js App Router.

## Setup (consumers)

```bash
# 1. Configure registry (one-time — no auth token needed)
echo '@sarvam:registry=https://asia-south1-npm.pkg.dev/saas-prod-457804/design-system/' >> .npmrc

# 2. Install
npm install @sarvam/tatva @hugeicons/react @hugeicons/core-free-icons react-hook-form zod sonner
```

After installing, configure Tailwind manually (see [Tailwind config](#tailwind-config) below), or use the `setup_tatva` MCP tool to auto-detect and patch your CSS / config.

### Peer dependencies

These must be in your app — Tatva does not bundle them:

```
react  ^18 || ^19
react-dom  ^18 || ^19
react-hook-form  ^7.50
sonner  ^1.4
zod  ^3.22
```

> **Note for `link:` / `file:` consumers (e.g. monorepo dev loops).**
> Tatva still installs `react` / `react-dom` under its own `node_modules`
> for its Storybook + Next demo. When a consumer pulls Tatva in via
> `link:` or `file:`, Node's resolution will pick up Tatva's React copy
> instead of the consumer's, and you'll see hook crashes
> (`Cannot read properties of null (reading 'useContext')`). Configure
> your bundler to dedupe React — Vite users add
> `resolve.dedupe: ["react", "react-dom", "react/jsx-runtime"]`. Webpack
> users add a matching `resolve.alias`. Released (registry-installed)
> consumers are unaffected.

### Imports

```tsx
// Components & types
import { Button, Table, Dialog } from "@sarvam/tatva";
import type { ButtonProps, TableColumn } from "@sarvam/tatva";

// Styles — add to your global CSS or root layout
import "@sarvam/tatva/styles.css";
```

All five subpath exports:

| Import                          | What                                               |
| ------------------------------- | -------------------------------------------------- |
| `@sarvam/tatva`                 | Components, types, variant helpers                 |
| `@sarvam/tatva/styles.css`      | Compiled token + component styles                  |
| `@sarvam/tatva/theme.css`       | CSS custom properties (light/dark)                 |
| `@sarvam/tatva/tailwind-preset` | Tailwind preset (colors, fonts, spacing, safelist) |
| `@sarvam/tatva/icon-context`    | `IconProvider` for registering custom icons        |

### Tailwind config

Add the Tatva preset manually, or call the `setup_tatva` MCP tool to patch your config automatically.

**Tailwind v3**

```ts
// tailwind.config.ts
import type { Config } from "tailwindcss";
const tatva = require("@sarvam/tatva/tailwind-preset");

const config: Config = {
  presets: [tatva],
  content: [
    "./app/**/*.{ts,tsx}",
    "./src/**/*.{ts,tsx}",
    "./node_modules/@sarvam/tatva/dist/**/*.{js,mjs}",
  ],
  darkMode: "class",
};
export default config;
```

**Tailwind v4**

```css
/* globals.css */
@import "tailwindcss";
@import "@sarvam/tatva/theme.css";
@source "../node_modules/@sarvam/tatva/dist/**/*.{js,mjs}";
```

### Icons

Tatva ships a built-in icon registry in `lib/icons.ts` — all valid names are defined in the `iconComponents` map (e.g. `"arrow-left"`, `"delete"`, `"search"`). Components that accept an `icon` prop resolve names from this registry.

To add custom icons, wrap your app with `IconProvider`:

```tsx
import { IconProvider } from "@sarvam/tatva/icon-context";
import { RocketIcon } from "@hugeicons/core-free-icons";

<IconProvider extend={{ rocket: RocketIcon }}>
  <Button icon="rocket">Launch</Button>
</IconProvider>;
```

Always import icon data from `@hugeicons/core-free-icons`, not `@hugeicons/react`. Browse glyphs at [hugeicons.com](https://hugeicons.com/icons).

### Toast setup

Drop `<Toaster />` once in your root layout:

```tsx
import { Toaster } from "@sarvam/tatva";

export default function RootLayout({ children }) {
  return (
    <html>
      <body>
        {children}
        <Toaster />
      </body>
    </html>
  );
}
```

---

## Setup (maintainers / contributors)

```bash
npm install          # installs everything
npm run storybook    # http://localhost:6006 — primary dev environment
```

### Day-to-day

```bash
npm run dev:lib:init   # full build then watch (tsup)
npm run dev:css        # optional: watch Tailwind → dist/styles.css
```

### Before pushing

```bash
npm run validate:ci    # lint + build:lib + storybook build + npm audit
```

### All scripts

| Script                      | What it does                                 |
| --------------------------- | -------------------------------------------- |
| `storybook`                 | Storybook dev server on :6006                |
| `build:lib`                 | Full production build → `dist/`              |
| `dev:lib`                   | tsup watch (no initial clean build)          |
| `dev:lib:init`              | `build:lib` then `dev:lib`                   |
| `dev:css`                   | Tailwind watch → `dist/styles.css`           |
| `build` / `build-storybook` | Static Storybook → `out/`                    |
| `lint`                      | ESLint (Next + Storybook + Tailwind plugins) |
| `validate:ci`               | Full CI pipeline locally                     |

### Build pipeline (`build:lib`)

1. **tsup** — bundles `index.ts`, `lib/utils.ts`, `lib/icon-context.ts` → `dist/*.mjs` + `dist/*.d.ts`. React and heavy deps are external.
2. **build:safelist** — scans dist JS for Tailwind classes → `dist/safelist.json` (so consumer bundlers that skip `node_modules` still get the right classes).
3. **build:css** — compiles `lib/styles.css` → `dist/styles.css`, copies `lib/theme.css`.
4. **build:fonts** — copies font files into `dist/fonts/`.

`prepublishOnly` runs `build:lib` automatically before every `npm publish`.

---

## Repo structure

```
index.ts                     Public API barrel (add exports here)
components/
  Button/
    index.tsx                Component implementation
    Button.stories.tsx       Storybook stories
  Table/
    index.tsx
    types.ts
    Table.stories.tsx
    ...
primitives/                  Shared low-level building blocks
lib/
  styles.css                 Global styles + token imports → dist/styles.css
  theme.css                  CSS custom properties → dist/theme.css
  utils.ts                   cn(), color helpers
  icon-context.ts            IconProvider
  icons.ts                   Built-in icon registry
tailwind-preset.cjs          Published Tailwind preset
tailwind.config.ts           Tailwind config for this repo's Storybook
mcp/                         MCP server (HTTP + tools)
  server.mjs                 HTTP entry point (deployed to tatva.sarvam.ai/mcp)
  tools/                     One file per MCP tool
.storybook/                  Storybook configuration
```

---

## Components

Accordion, AnnouncementBanner, AssetContainer, Avatar, AvatarGroup, Badge, Breadcrumbs, Button, ButtonGroup, Card, ChatInput, Checkbox, Chip, DatePicker, DateRangePicker, Dialog, Divider, EmptyState, FileUpload, Filters, Header, Icon, Input, KeyValue, List, Loader, Menu, MetricCard, Radio, Select, Sheet, Sidebar, Skeleton, Slider, Stepper, Switch, Table, Tabs, Tag, TagInput, Text, Textarea, TimePicker, Toast, Tooltip

All components export their props types. Most expose CVA variant helpers (e.g. `buttonVariants`, `badgeVariants`) for use outside the component.

Full interactive docs: `npm run storybook`.

---

## Adding a component

1. Create `components/<Name>/index.tsx` and `components/<Name>/<Name>.stories.tsx`.
2. Use CVA for variants, Radix primitives where applicable, `tatva-*` token classes.
3. Export the component and its types from `index.ts`.
4. Run `npm run validate:ci`.

### Conventions

- **Styling:** CVA + Tailwind with semantic `tatva-`\* tokens. No hardcoded colors.
- **Path alias:** `@/`\* → repo root.
- **Linting:** ESLint + Prettier, enforced on commit via Husky + lint-staged.
- **Fonts:** Matter (sans) and Season (display), loaded via CSS variables.

---

## Agent integration

Tatva ships first-class AI agent support via an MCP server and a set of coding rules.

### 1. Tatva MCP (Model Context Protocol)

Add to `~/.cursor/mcp.json`:

```json
{
  "mcpServers": {
    "tatva-mcp": {
      "url": "https://tatva.sarvam.ai/mcp"
    }
  }
}
```

Restart your editor after adding it. The MCP exposes these tools:

| Tool                          | Purpose                                                                                                                     |
| ----------------------------- | --------------------------------------------------------------------------------------------------------------------------- |
| `setup_tatva`                 | Set up @sarvam/tatva in a new project — installs package, writes IDE rules, configures Tailwind. Skip if already installed. |
| `get_component_docs`          | Fetch full docs (props, variants, examples) for multiple components in one call                                             |
| `get-documentation-for-story` | Concrete copy-paste code for a specific story variant                                                                       |

**Recommended agent workflow:**

1. **Check setup** — if `@sarvam/tatva` is already in `package.json`, skip to step 2. Otherwise run `setup_tatva`.
2. **Start dev server** — run `npm run dev` before writing any UI code.
3. **Fetch docs** — call `get_component_docs` with all components needed in one call.
4. **Build UI** — use only `@sarvam/tatva` components. Fix TypeScript errors by re-reading docs, not guessing.

**Prompts (slash commands):**

Type `/` in Cursor chat to access these prompt templates:

| Prompt                     | What it does                                                                                             |
| -------------------------- | -------------------------------------------------------------------------------------------------------- |
| `/tatva-copywriter`        | Write professional UI copy — concise buttons, clear empty states, helpful errors, realistic placeholders |
| `/tatva-figma-to-tatva`    | Fetch a Figma design via Figma MCP and convert it to Tatva components with correct tokens                |
| `/tatva-refactor-to-tatva` | Migrate raw HTML / Tailwind / custom components to Tatva. Preserves business logic.                      |

**Key rules enforced by the MCP:**

- Keep changes limited to frontend code only — no API routes unless explicitly asked.
- Use `MetricCard` for card-like structures with title, description, and children.
- Never guess icon names — read `lib/icons.ts` → `iconComponents` for built-in names. Check `IconProvider` `extend` prop for project-specific additions.
- Never use raw Tailwind classes (`p-4`, `text-gray-500`) — use `tatva-` prefixed tokens only.

### 2. Rules (`.agent/rules/tatva-frontend.mdc`)

An always-on rule file installed into consumer projects by `setup_tatva`. It covers:

- MCP workflow (when to call which tool)
- Styling system (spacing scale, color tokens, border radius, typography, shadows)
- Component selection guide (which component to use for which pattern)
- Icon usage (built-in registry in `lib/icons.ts`, extending via `IconProvider`)
- Layout best practices, sizing conventions, form patterns
- Code practices (TypeScript, naming, state management, imports)

To install manually:

```bash
mkdir -p .cursor/rules
cp node_modules/@sarvam/tatva/.agent/rules/tatva-frontend.mdc .cursor/rules/tatva-frontend.mdc
```

### How it works together

1. The **rule** fires automatically and directs the agent to call the **MCP**
2. `setup_tatva` installs the package, writes IDE rules, and configures Tailwind
3. `get_component_docs` returns exact props and copy-paste examples
4. Result: correct components, correct props, correct tokens — no hallucinated APIs

### For maintainers

Source files in this repo:

- `.agent/rules/tatva-frontend.mdc` — rule source (installed into consumer projects by `setup_tatva`)
- `mcp/` — MCP server (HTTP transport + tool modules)
- `mcp/server.mjs` — HTTP entry point with workflow instructions (`npm run mcp:serve`)
- `mcp/tools/` — one file per custom tool (`setup.mjs`, `batch-docs.mjs`)

All included in the published package via `"files"` in `package.json`. Edit here, publish, consumers get the update.

---

## Troubleshooting

**Tatva classes missing in my app** — Make sure `content` in your Tailwind config includes `node_modules/@sarvam/tatva/dist/**/*.{js,mjs}` and the preset is applied. If using `npm link`, run `npm run build:lib` in this repo first.

**Styles not showing up** — Verify `@sarvam/tatva/styles.css` is imported in your global CSS.

**Type errors after upgrade** — Check React version matches peers (`^18` or `^19`).

**Tatva MCP not working** — Restart your editor after adding the MCP entry to `~/.cursor/mcp.json`. The server is hosted at `https://tatva.sarvam.ai/mcp` — no local process needed.

**CSS / Tailwind not configured** — Run `setup_tatva` via the MCP with your project root, or configure manually (see [Tailwind config](#tailwind-config) above).

**Rules not appearing** — Run `setup_tatva` from the MCP, or copy manually: `cp node_modules/@sarvam/tatva/.agent/rules/tatva-frontend.mdc .cursor/rules/tatva-frontend.mdc`.

**Agent using wrong icon names** — Icon names must match keys in `lib/icons.ts` → `iconComponents`. If the project extends icons via `IconProvider`, check its `extend` prop for additional valid names.

**Agent using wrong props** — Call `get_component_docs` to re-fetch the latest docs. Never guess props from prior knowledge.
